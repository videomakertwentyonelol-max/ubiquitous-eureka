/**
 * Adapter for claude.ai.
 *
 * TESTED STATUS: implemented against publicly documented/observed DOM
 * patterns as of this writing. Claude's web UI does not publish a stable
 * DOM contract; selectors below use layered fallbacks and fail closed
 * (treat as "not ready" / "still streaming") rather than guessing. See
 * docs/SUPPORTED_PLATFORMS.md.
 */
(function (global) {
  const BaseAdapter = global.ZeroScriptBaseAdapter;

  const ASSISTANT_SELECTORS = [
    '[data-testid="assistant-message"]',
    ".font-claude-message",
    ".font-claude-response",
  ];

  const STREAMING_INDICATOR_SELECTORS = [
    '[data-is-streaming="true"]',
    ".result-streaming",
  ];

  const INPUT_SELECTORS = [
    'div[contenteditable="true"][data-testid]',
    'div[contenteditable="true"].ProseMirror',
    'div[contenteditable="true"][class*="composer"]',
    'div[contenteditable="true"]',
  ];

  const SEND_BUTTON_SELECTORS = [
    'button[aria-label="Send Message"]',
    'button[data-testid="send-button"]',
  ];

  function queryFirst(selectors, root = document) {
    for (const sel of selectors) {
      const el = root.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  class ClaudeAdapter extends BaseAdapter {
    constructor() {
      super("claude");
    }

    getAssistantMessageElements() {
      for (const sel of ASSISTANT_SELECTORS) {
        const nodes = document.querySelectorAll(sel);
        if (nodes.length > 0) return Array.from(nodes);
      }
      return [];
    }

    getMessageText(el) {
      return el.innerText || "";
    }

    isMessageStreaming(el) {
      if (queryFirst(STREAMING_INDICATOR_SELECTORS)) return true;
      // Ancestor-based check: some Claude layouts mark the turn container,
      // not the message node itself.
      let node = el;
      for (let i = 0; i < 5 && node; i++) {
        for (const sel of STREAMING_INDICATOR_SELECTORS) {
          if (node.matches && node.matches(sel)) return true;
        }
        node = node.parentElement;
      }
      return false;
    }

    getInputElement() {
      return queryFirst(INPUT_SELECTORS);
    }

    setInputText(el, text) {
      el.focus();
      el.innerText = "";
      document.execCommand && document.execCommand("insertText", false, text);
      if (el.innerText.trim() === "") {
        el.textContent = text;
      }
      BaseAdapter.dispatchNativeInputEvents(el);
    }

    submitInput() {
      const sendBtn = queryFirst(SEND_BUTTON_SELECTORS);
      if (sendBtn && !sendBtn.disabled) {
        sendBtn.click();
        return true;
      }
      const input = this.getInputElement();
      if (input) {
        input.dispatchEvent(
          new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true })
        );
        return true;
      }
      return false;
    }
  }

  global.ZeroScriptAdapter = new ClaudeAdapter();
})(window);
