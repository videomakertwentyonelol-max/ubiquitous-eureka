/**
 * Adapter for chatgpt.com / chat.openai.com.
 *
 * TESTED STATUS: implemented against publicly documented/observed DOM
 * patterns as of this writing. ChatGPT's web UI changes its markup
 * periodically (see docs/SUPPORTED_PLATFORMS.md); selectors below use
 * layered fallbacks and fail closed (treat as "not ready" / "still
 * streaming") rather than guessing.
 */
(function (global) {
  const BaseAdapter = global.ZeroScriptBaseAdapter;

  const ASSISTANT_SELECTORS = [
    '[data-message-author-role="assistant"]',
    '[data-testid^="conversation-turn-"] [data-turn="assistant"]',
  ];

  const STOP_BUTTON_SELECTORS = [
    'button[data-testid="stop-button"]',
    'button[aria-label^="Stop"]',
    'button[aria-label="Stop generating"]',
  ];

  const INPUT_SELECTORS = [
    "#prompt-textarea",
    'div[contenteditable="true"][role="textbox"]',
    'div[contenteditable="true"]',
  ];

  const SEND_BUTTON_SELECTORS = [
    'button[data-testid="send-button"]',
    'button[aria-label="Send prompt"]',
    'button[aria-label="Send"]',
  ];

  function queryFirst(selectors, root = document) {
    for (const sel of selectors) {
      const el = root.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  class ChatGptAdapter extends BaseAdapter {
    constructor() {
      super("chatgpt");
    }

    getAssistantMessageElements() {
      for (const sel of ASSISTANT_SELECTORS) {
        const nodes = document.querySelectorAll(sel);
        if (nodes.length > 0) return Array.from(nodes);
      }
      return [];
    }

    getMessageText(el) {
      return el.innerText || "";
    }

    isMessageStreaming(_el) {
      // ChatGPT only streams the most recent turn at a time; if a stop
      // button is visible anywhere, treat the latest assistant message as
      // still streaming. This is intentionally conservative.
      return !!queryFirst(STOP_BUTTON_SELECTORS);
    }

    getInputElement() {
      return queryFirst(INPUT_SELECTORS);
    }

    setInputText(el, text) {
      el.focus();
      if (el.tagName === "TEXTAREA") {
        BaseAdapter.setNativeValue(el, text);
      } else {
        // contenteditable (ProseMirror-style) editor.
        el.innerText = "";
        document.execCommand && document.execCommand("insertText", false, text);
        if (el.innerText.trim() === "") {
          el.textContent = text;
        }
        BaseAdapter.dispatchNativeInputEvents(el);
      }
    }

    submitInput() {
      const sendBtn = queryFirst(SEND_BUTTON_SELECTORS);
      if (sendBtn && !sendBtn.disabled) {
        sendBtn.click();
        return true;
      }
      const input = this.getInputElement();
      if (input) {
        input.dispatchEvent(
          new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true })
        );
        return true;
      }
      return false;
    }
  }

  global.ZeroScriptAdapter = new ChatGptAdapter();
})(window);
