/**
 * Base class for a per-platform chat adapter. Each supported AI chat site
 * gets its own subclass because DOM structure is not shared across sites
 * and changes over time. See docs/SUPPORTED_PLATFORMS.md for exactly which
 * platforms have adapters here and their known limitations.
 */
(function (global) {
  class BaseAdapter {
    constructor(platformId) {
      this.platformId = platformId;
    }

    /** Return an array of current assistant message container elements. */
    getAssistantMessageElements() {
      throw new Error("not implemented");
    }

    /** Extract the plain text content of a message element. */
    getMessageText(_el) {
      throw new Error("not implemented");
    }

    /**
     * Return true while the given message is still streaming/generating.
     * Implementations must be conservative: when unsure, return true
     * (treat as incomplete) rather than risk parsing partial JSON.
     */
    isMessageStreaming(_el) {
      throw new Error("not implemented");
    }

    /** Return a stable-ish identifier for a message element for dedupe purposes. */
    getMessageDomId(el) {
      return el.getAttribute("data-message-id") || el.getAttribute("data-testid") || null;
    }

    /** Return the chat input element (textarea or contenteditable). */
    getInputElement() {
      throw new Error("not implemented");
    }

    /** Programmatically set the chat input's text content. */
    setInputText(_el, _text) {
      throw new Error("not implemented");
    }

    /** Programmatically submit the chat input. */
    submitInput() {
      throw new Error("not implemented");
    }

    /** Returns true if this page currently looks like a usable chat view. */
    isReady() {
      return !!this.getInputElement();
    }

    // ---- Shared DOM helpers available to subclasses ----
    static dispatchNativeInputEvents(el) {
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }

    static setNativeValue(el, value) {
      const proto = Object.getPrototypeOf(el);
      const descriptor = Object.getOwnPropertyDescriptor(proto, "value");
      if (descriptor && descriptor.set) {
        descriptor.set.call(el, value);
      } else {
        el.value = value;
      }
      BaseAdapter.dispatchNativeInputEvents(el);
    }
  }

  global.ZeroScriptBaseAdapter = BaseAdapter;
})(window);
