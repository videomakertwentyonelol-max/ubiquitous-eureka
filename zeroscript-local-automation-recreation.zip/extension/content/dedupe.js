/**
 * Prevents the same structured tool request from being executed twice, and
 * prevents re-scanning text that is still streaming in.
 */
(function (global) {
  class DedupeTracker {
    constructor() {
      this._processedRequestIds = new Set();
      this._processedMessageHashes = new Set();
    }

    hasProcessedRequest(requestId) {
      return this._processedRequestIds.has(requestId);
    }

    markRequestProcessed(requestId) {
      this._processedRequestIds.add(requestId);
    }

    /** Cheap hash so we don't re-scan/re-submit an identical message node twice. */
    hashMessage(text) {
      let h = 0;
      for (let i = 0; i < text.length; i++) {
        h = (Math.imul(31, h) + text.charCodeAt(i)) | 0;
      }
      return `${text.length}:${h}`;
    }

    hasProcessedMessage(hash) {
      return this._processedMessageHashes.has(hash);
    }

    markMessageProcessed(hash) {
      this._processedMessageHashes.add(hash);
    }
  }

  global.ZeroScriptDedupe = new DedupeTracker();
})(window);
