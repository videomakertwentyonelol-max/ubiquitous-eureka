/**
 * Shared structured tool-call protocol (client side). Mirrors
 * bridge/zeroscript_bridge/protocol.py. Protocol version strings must match
 * exactly; the bridge re-validates everything independently, this is a
 * first line of defense so obviously-malformed text is never even sent.
 */
(function (global) {
  const PROTOCOL_TOOL_CALL = "zeroscript.tool_call/1";
  const PROTOCOL_TOOL_RESULT = "zeroscript.tool_result/1";
  const PROTOCOL_HELLO = "zeroscript.hello/1";

  const UUID_RE = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
  const TOOL_NAME_RE = /^[a-z][a-z0-9_]*\.[a-z][a-z0-9_]*$/;

  // Fenced code block tag the AI must use to emit a tool call, e.g.:
  // ```zeroscript-tool
  // { "protocol": "zeroscript.tool_call/1", ... }
  // ```
  const FENCE_RE = /```zeroscript-tool\s*\n([\s\S]*?)```/g;

  function validateToolCall(obj) {
    const errors = [];
    if (typeof obj !== "object" || obj === null || Array.isArray(obj)) {
      return { valid: false, errors: ["payload is not a JSON object"] };
    }
    if (obj.protocol !== PROTOCOL_TOOL_CALL) {
      errors.push(`protocol must be "${PROTOCOL_TOOL_CALL}"`);
    }
    if (typeof obj.request_id !== "string" || !UUID_RE.test(obj.request_id)) {
      errors.push("request_id must be a UUIDv4-shaped string");
    }
    if (typeof obj.tool !== "string" || !TOOL_NAME_RE.test(obj.tool) || obj.tool.length > 128) {
      errors.push("tool must look like '<integration>.<action>'");
    }
    if (typeof obj.arguments !== "object" || obj.arguments === null || Array.isArray(obj.arguments)) {
      errors.push("arguments must be a JSON object");
    }
    const allowedKeys = new Set([
      "protocol",
      "request_id",
      "tool",
      "arguments",
      "created_at",
      "requires_confirmation",
      "source",
    ]);
    for (const key of Object.keys(obj)) {
      if (!allowedKeys.has(key)) {
        errors.push(`unexpected field '${key}'`);
      }
    }
    return { valid: errors.length === 0, errors };
  }

  /**
   * Extract candidate tool-call JSON blocks from a completed (non-streaming)
   * assistant message's text content. Returns an array of
   * { raw: string, parsed: object|null, validation } entries.
   */
  function extractToolCalls(messageText) {
    const found = [];
    let match;
    FENCE_RE.lastIndex = 0;
    while ((match = FENCE_RE.exec(messageText)) !== null) {
      const raw = match[1].trim();
      let parsed = null;
      let validation = { valid: false, errors: ["not valid JSON"] };
      try {
        parsed = JSON.parse(raw);
        validation = validateToolCall(parsed);
      } catch (e) {
        validation = { valid: false, errors: [`JSON parse error: ${e.message}`] };
      }
      found.push({ raw, parsed, validation });
    }
    return found;
  }

  function newRequestId() {
    if (crypto && crypto.randomUUID) return crypto.randomUUID();
    // Fallback UUIDv4 generator.
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      const v = c === "x" ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  }

  /** Formats a tool_result for insertion back into the chat input. */
  function formatResultBlock(resultMessage) {
    return "```zeroscript-result\n" + JSON.stringify(resultMessage, null, 2) + "\n```";
  }

  global.ZeroScriptProtocol = {
    PROTOCOL_TOOL_CALL,
    PROTOCOL_TOOL_RESULT,
    PROTOCOL_HELLO,
    validateToolCall,
    extractToolCalls,
    newRequestId,
    formatResultBlock,
  };
})(window);
