/**
 * Shared content-script controller, loaded last. Wires up the platform
 * adapter, the shared protocol/dedupe helpers, a minimal floating control
 * bar, and messaging with the background service worker (which owns the
 * actual WebSocket connection to the local bridge).
 */
(function () {
  const adapter = window.ZeroScriptAdapter;
  const Protocol = window.ZeroScriptProtocol;
  const Dedupe = window.ZeroScriptDedupe;

  if (!adapter || !Protocol || !Dedupe) {
    console.warn("[ZeroScript] adapter/protocol not loaded, aborting content script");
    return;
  }

  let sessionActive = false;
  let lastConnectionState = "disconnected";
  const logLines = [];

  function log(line) {
    const stamped = `${new Date().toLocaleTimeString()}  ${line}`;
    logLines.push(stamped);
    if (logLines.length > 50) logLines.shift();
    renderLog();
  }

  // ---- Control bar UI --------------------------------------------------
  let bar, dot, statusText, sessionBtn, logBox, confirmBox;

  function buildControlBar() {
    bar = document.createElement("div");
    bar.id = "zeroscript-control-bar";
    bar.innerHTML = `
      <div class="zs-header">
        <div class="zs-header-title"><span class="zs-dot disconnected"></span> ZeroScript</div>
        <span class="zs-caret">▾</span>
      </div>
      <div class="zs-body">
        <div class="zs-row"><span id="zs-status-text">Disconnected from bridge</span></div>
        <div class="zs-row">
          <button class="zs-btn zs-primary" id="zs-session-btn">Start Session</button>
          <button class="zs-btn" id="zs-instructions-btn">Insert Tool Instructions</button>
        </div>
        <div id="zs-confirm-area"></div>
        <div class="zs-log" id="zs-log"></div>
      </div>
    `;
    document.documentElement.appendChild(bar);

    dot = bar.querySelector(".zs-dot");
    statusText = bar.querySelector("#zs-status-text");
    sessionBtn = bar.querySelector("#zs-session-btn");
    logBox = bar.querySelector("#zs-log");
    confirmBox = bar.querySelector("#zs-confirm-area");

    bar.querySelector(".zs-header").addEventListener("click", () => {
      bar.classList.toggle("zs-collapsed");
    });

    sessionBtn.addEventListener("click", () => {
      sessionActive = !sessionActive;
      chrome.runtime.sendMessage({ type: "SESSION_TOGGLE", active: sessionActive, platform: adapter.platformId });
      sessionBtn.textContent = sessionActive ? "Stop Session" : "Start Session";
      sessionBtn.classList.toggle("zs-danger", sessionActive);
      log(sessionActive ? "Session started by user" : "Session stopped by user");
    });

    bar.querySelector("#zs-instructions-btn").addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "GET_TOOL_INSTRUCTIONS" }, (resp) => {
        const input = adapter.getInputElement();
        if (!input || !resp || !resp.text) {
          log("Could not insert instructions: input box not found or bridge not connected");
          return;
        }
        adapter.setInputText(input, resp.text);
        log("Inserted ZeroScript tool instructions into the chat input. Review, then press send.");
      });
    });
  }

  function renderLog() {
    if (!logBox) return;
    logBox.textContent = logLines.join("\n");
    logBox.scrollTop = logBox.scrollHeight;
  }

  function setConnectionState(state) {
    lastConnectionState = state;
    if (!dot) return;
    dot.className = `zs-dot ${state}`;
    statusText.textContent =
      state === "connected"
        ? "Connected to local bridge"
        : state === "connecting"
        ? "Connecting to local bridge..."
        : "Disconnected from bridge";
  }

  function showConfirmation(toolCall) {
    const id = toolCall.request_id;
    const box = document.createElement("div");
    box.className = "zs-confirm-box";
    box.innerHTML = `
      <div><strong>Confirm:</strong> ${toolCall.tool}</div>
      <div style="opacity:.8;margin:4px 0;">${JSON.stringify(toolCall.arguments)}</div>
      <div class="zs-row">
        <button class="zs-btn zs-primary zs-approve">Approve</button>
        <button class="zs-btn zs-danger zs-deny">Deny</button>
      </div>
    `;
    confirmBox.appendChild(box);
    box.querySelector(".zs-approve").addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "CONFIRM_RESPONSE", requestId: id, approved: true });
      box.remove();
      log(`Approved ${toolCall.tool} (${id.slice(0, 8)})`);
    });
    box.querySelector(".zs-deny").addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "CONFIRM_RESPONSE", requestId: id, approved: false });
      box.remove();
      log(`Denied ${toolCall.tool} (${id.slice(0, 8)})`);
    });
  }

  // ---- Messages from background ------------------------------------------
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === "STATUS_UPDATE") {
      setConnectionState(msg.state);
    } else if (msg.type === "LOG") {
      log(msg.line);
    } else if (msg.type === "CONFIRMATION_REQUEST") {
      showConfirmation(msg.toolCall);
    } else if (msg.type === "DELIVER_RESULT") {
      const input = adapter.getInputElement();
      if (input) {
        const block = Protocol.formatResultBlock(msg.resultMessage);
        adapter.setInputText(input, block);
        log(`Tool result ready for request ${msg.resultMessage.request_id.slice(0, 8)} (status=${msg.resultMessage.status}). Inserted into chat input.`);
        if (msg.autoSubmit) {
          setTimeout(() => adapter.submitInput(), 150);
        }
      }
    }
    sendResponse && sendResponse({ ok: true });
  });

  // ---- Scanning for completed tool calls ----------------------------------
  let pendingHash = null;
  let pendingTimer = null;

  function scanLatestMessage() {
    if (!sessionActive) return;
    const messages = adapter.getAssistantMessageElements();
    if (messages.length === 0) return;
    const last = messages[messages.length - 1];

    if (adapter.isMessageStreaming(last)) {
      // Never parse a streaming/incomplete message.
      pendingHash = null;
      return;
    }

    const text = adapter.getMessageText(last);
    const hash = Dedupe.hashMessage(text);

    if (hash === pendingHash) return; // nothing changed since last stable check
    pendingHash = hash;

    // Debounce: require the message to stay stable for 700ms after it is
    // reported as "not streaming" before we trust it as complete. Guards
    // against adapters whose streaming flag flips a moment late.
    if (pendingTimer) clearTimeout(pendingTimer);
    pendingTimer = setTimeout(() => {
      if (Dedupe.hasProcessedMessage(hash)) return;
      if (adapter.isMessageStreaming(last)) return;
      const currentText = adapter.getMessageText(last);
      if (Dedupe.hashMessage(currentText) !== hash) return; // changed again, wait for next cycle
      Dedupe.markMessageProcessed(hash);
      processCompletedMessage(currentText);
    }, 700);
  }

  function processCompletedMessage(text) {
    const candidates = Protocol.extractToolCalls(text);
    for (const candidate of candidates) {
      if (!candidate.validation.valid) {
        if (candidate.raw.length > 0) {
          log(`Ignored malformed zeroscript-tool block: ${candidate.validation.errors.join("; ")}`);
        }
        continue;
      }
      const toolCall = candidate.parsed;
      if (Dedupe.hasProcessedRequest(toolCall.request_id)) {
        continue; // already executed once -- never execute the same request_id twice
      }
      Dedupe.markRequestProcessed(toolCall.request_id);
      log(`Detected tool call ${toolCall.tool} (${toolCall.request_id.slice(0, 8)})`);
      chrome.runtime.sendMessage({
        type: "TOOL_CALL_DETECTED",
        toolCall,
        platform: adapter.platformId,
      });
    }
  }

  const observer = new MutationObserver(() => scanLatestMessage());

  function start() {
    buildControlBar();
    chrome.runtime.sendMessage({ type: "CONTENT_READY", platform: adapter.platformId }, (resp) => {
      if (resp && resp.connectionState) setConnectionState(resp.connectionState);
    });
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    log(`ZeroScript adapter loaded for ${adapter.platformId}`);
  }

  if (document.readyState === "complete" || document.readyState === "interactive") {
    start();
  } else {
    window.addEventListener("DOMContentLoaded", start);
  }
})();
