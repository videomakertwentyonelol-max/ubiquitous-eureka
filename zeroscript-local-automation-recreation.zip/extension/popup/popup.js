const dot = document.getElementById("dot");
const statusLine = document.getElementById("status-line");
const bridgeUrlInput = document.getElementById("bridge-url");
const bridgeTokenInput = document.getElementById("bridge-token");
const autoSubmitInput = document.getElementById("auto-submit");
const toolList = document.getElementById("tool-list");
const toolCount = document.getElementById("tool-count");

function render(state) {
  dot.className = `dot ${state.connectionState}`;
  statusLine.textContent =
    state.connectionState === "connected"
      ? "Connected to local bridge."
      : state.connectionState === "connecting"
      ? "Connecting to local bridge..."
      : state.hasToken
      ? "Disconnected. Is the bridge running (start_bridge.ps1)?"
      : "Not paired yet. Paste your pairing token below.";
  bridgeUrlInput.value = state.bridgeUrl || "";
  autoSubmitInput.checked = !!state.autoSubmit;
  toolCount.textContent = (state.tools || []).length;
  toolList.innerHTML = "";
  for (const t of state.tools || []) {
    const li = document.createElement("li");
    li.textContent = `${t.name}${t.consequential ? " 🔒" : ""}`;
    li.title = t.description;
    toolList.appendChild(li);
  }
}

function refresh() {
  chrome.runtime.sendMessage({ type: "GET_STATE" }, (resp) => {
    if (resp) render(resp);
  });
}

document.getElementById("save-btn").addEventListener("click", () => {
  chrome.runtime.sendMessage(
    {
      type: "SET_CONFIG",
      bridgeUrl: bridgeUrlInput.value.trim() || "ws://127.0.0.1:8765/ws",
      token: bridgeTokenInput.value.trim(),
    },
    () => {
      bridgeTokenInput.value = "";
      setTimeout(refresh, 400);
    }
  );
});

autoSubmitInput.addEventListener("change", () => {
  chrome.runtime.sendMessage({ type: "SET_AUTOSUBMIT", value: autoSubmitInput.checked });
});

refresh();
setInterval(refresh, 2000);
