/**
 * Background service worker: owns the single WebSocket connection to the
 * local Python bridge (never done from content scripts, since the page's
 * own CSP could block it, and to keep one connection per browser instead
 * of one per tab). Relays detected tool calls from content scripts to the
 * bridge, enforces a client-side confirmation step for consequential
 * tools (the bridge enforces this independently too), and relays tool
 * results back to the originating tab.
 *
 * This file performs NO AI inference and never talks to a paid model API.
 */

const DEFAULT_BRIDGE_URL = "ws://127.0.0.1:8765/ws";
const PROTOCOL_HELLO = "zeroscript.hello/1";
const CLIENT_VERSION = "1.0.0";

let ws = null;
let connectionState = "disconnected"; // disconnected | connecting | connected
let reconnectDelayMs = 1000;
let reconnectTimer = null;
let toolCatalog = []; // [{name, description, argument_schema, consequential}]
let sessionId = null;

const pendingResultTabByRequestId = new Map(); // request_id -> tabId
const pendingConfirmations = new Map(); // request_id -> { toolCall, tabId }
let autoSubmit = false;

async function getConfig() {
  const stored = await chrome.storage.local.get(["zsBridgeUrl", "zsBridgeToken", "zsAutoSubmit"]);
  autoSubmit = !!stored.zsAutoSubmit;
  return {
    bridgeUrl: stored.zsBridgeUrl || DEFAULT_BRIDGE_URL,
    token: stored.zsBridgeToken || "",
  };
}

function broadcastStatus() {
  chrome.tabs.query({}, (tabs) => {
    for (const tab of tabs) {
      chrome.tabs.sendMessage(tab.id, { type: "STATUS_UPDATE", state: connectionState }, () => {
        void chrome.runtime.lastError; // ignore tabs without our content script
      });
    }
  });
}

function broadcastLog(line) {
  chrome.tabs.query({}, (tabs) => {
    for (const tab of tabs) {
      chrome.tabs.sendMessage(tab.id, { type: "LOG", line }, () => {
        void chrome.runtime.lastError;
      });
    }
  });
}

async function connect() {
  const { bridgeUrl, token } = await getConfig();
  if (!token) {
    connectionState = "disconnected";
    broadcastStatus();
    return; // Wait for the user to pair via the popup.
  }

  connectionState = "connecting";
  broadcastStatus();

  try {
    ws = new WebSocket(bridgeUrl);
  } catch (e) {
    scheduleReconnect();
    return;
  }

  ws.addEventListener("open", () => {
    ws.send(
      JSON.stringify({
        protocol: PROTOCOL_HELLO,
        type: "hello",
        token,
        client_version: CLIENT_VERSION,
        platform: "extension",
      })
    );
  });

  ws.addEventListener("message", (event) => {
    let data;
    try {
      data = JSON.parse(event.data);
    } catch {
      return;
    }
    handleBridgeMessage(data);
  });

  ws.addEventListener("close", () => {
    connectionState = "disconnected";
    broadcastStatus();
    scheduleReconnect();
  });

  ws.addEventListener("error", () => {
    // 'close' will also fire; avoid double-scheduling by letting close handle it.
  });
}

function scheduleReconnect() {
  if (reconnectTimer) return;
  reconnectTimer = setTimeout(async () => {
    reconnectTimer = null;
    reconnectDelayMs = Math.min(reconnectDelayMs * 1.6, 15000);
    await connect();
  }, reconnectDelayMs);
}

function handleBridgeMessage(data) {
  if (data.type === "hello_ack") {
    connectionState = "connected";
    reconnectDelayMs = 1000;
    sessionId = data.session_id;
    toolCatalog = data.tools || [];
    broadcastStatus();
    broadcastLog(`Connected to bridge (session ${sessionId?.slice(0, 8)}). ${toolCatalog.length} tools available.`);
    return;
  }
  if (data.type === "error") {
    broadcastLog(`Bridge error: ${data.code} - ${data.message}`);
    if (data.request_id) {
      deliverResultToTab(data.request_id, {
        protocol: "zeroscript.tool_result/1",
        request_id: data.request_id,
        status: "error",
        error: { code: data.code, message: data.message },
      });
    }
    return;
  }
  if (data.protocol === "zeroscript.tool_result/1") {
    deliverResultToTab(data.request_id, data);
    return;
  }
  if (data.type === "pong") {
    return;
  }
}

function deliverResultToTab(requestId, resultMessage) {
  const tabId = pendingResultTabByRequestId.get(requestId);
  pendingResultTabByRequestId.delete(requestId);
  if (tabId == null) return;
  chrome.tabs.sendMessage(tabId, { type: "DELIVER_RESULT", resultMessage, autoSubmit }, () => {
    void chrome.runtime.lastError;
  });
}

function findToolSpec(toolName) {
  return toolCatalog.find((t) => t.name === toolName);
}

async function forwardToolCall(toolCall, tabId) {
  if (!ws || ws.readyState !== WebSocket.OPEN) {
    chrome.tabs.sendMessage(tabId, {
      type: "DELIVER_RESULT",
      resultMessage: {
        protocol: "zeroscript.tool_result/1",
        request_id: toolCall.request_id,
        status: "error",
        error: { code: "bridge_not_connected", message: "Not connected to the local ZeroScript bridge." },
      },
      autoSubmit: false,
    });
    return;
  }
  pendingResultTabByRequestId.set(toolCall.request_id, tabId);
  ws.send(JSON.stringify({ type: "tool_call", ...toolCall }));
}

chrome.runtime.onInstalled.addListener(() => {
  connect();
});
chrome.runtime.onStartup.addListener(() => {
  connect();
});
connect();

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const tabId = sender.tab ? sender.tab.id : null;

  if (msg.type === "CONTENT_READY") {
    sendResponse({ connectionState });
    return true;
  }

  if (msg.type === "SESSION_TOGGLE") {
    broadcastLog(`Session ${msg.active ? "started" : "stopped"} on ${msg.platform}`);
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === "TOOL_CALL_DETECTED") {
    const toolCall = msg.toolCall;
    const spec = findToolSpec(toolCall.tool);
    const isConsequential = spec ? spec.consequential : true; // fail safe: unknown => treat as consequential

    if (isConsequential && !toolCall.requires_confirmation) {
      pendingConfirmations.set(toolCall.request_id, { toolCall, tabId });
      chrome.tabs.sendMessage(tabId, { type: "CONFIRMATION_REQUEST", toolCall }, () => {
        void chrome.runtime.lastError;
      });
    } else {
      forwardToolCall(toolCall, tabId);
    }
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === "CONFIRM_RESPONSE") {
    const pending = pendingConfirmations.get(msg.requestId);
    pendingConfirmations.delete(msg.requestId);
    if (!pending) {
      sendResponse({ ok: false });
      return true;
    }
    if (msg.approved) {
      const confirmedCall = { ...pending.toolCall, requires_confirmation: true };
      forwardToolCall(confirmedCall, pending.tabId);
    } else {
      chrome.tabs.sendMessage(pending.tabId, {
        type: "DELIVER_RESULT",
        resultMessage: {
          protocol: "zeroscript.tool_result/1",
          request_id: msg.requestId,
          status: "error",
          error: { code: "user_denied", message: "The user denied this operation in the ZeroScript extension." },
        },
        autoSubmit: false,
      });
    }
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === "GET_TOOL_INSTRUCTIONS") {
    sendResponse({ text: buildInstructionsText() });
    return true;
  }

  if (msg.type === "GET_STATE") {
    getConfig().then(({ bridgeUrl, token }) => {
      sendResponse({ connectionState, tools: toolCatalog, bridgeUrl, hasToken: !!token, autoSubmit });
    });
    return true;
  }

  if (msg.type === "SET_CONFIG") {
    chrome.storage.local.set({ zsBridgeUrl: msg.bridgeUrl, zsBridgeToken: msg.token }).then(() => {
      reconnectDelayMs = 1000;
      if (ws) {
        try {
          ws.close();
        } catch {
          /* noop */
        }
      }
      connect();
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg.type === "SET_AUTOSUBMIT") {
    chrome.storage.local.set({ zsAutoSubmit: !!msg.value }).then(() => {
      autoSubmit = !!msg.value;
      sendResponse({ ok: true });
    });
    return true;
  }

  return false;
});

function buildInstructionsText() {
  const toolLines = (toolCatalog.length ? toolCatalog : []).map(
    (t) => `- ${t.name}${t.consequential ? " (requires user confirmation)" : ""}: ${t.description}`
  );
  const toolSection = toolLines.length
    ? toolLines.join("\n")
    : "(Not connected to the local bridge yet -- start it and pair the extension to see the live tool list.)";

  return [
    "You are connected to ZeroScript, a local tool-execution bridge. When the user asks you to",
    "perform an action in a connected local application (Roblox Studio, Blender, or Sketchfab),",
    "respond with a single fenced code block tagged `zeroscript-tool` containing ONLY a JSON object",
    "in this exact shape, and nothing else inside the block:",
    "",
    "```zeroscript-tool",
    "{",
    '  "protocol": "zeroscript.tool_call/1",',
    '  "request_id": "<a new random UUIDv4>",',
    '  "tool": "<tool name from the list below>",',
    '  "arguments": { }',
    "}",
    "```",
    "",
    "Only use tool names from this list, with arguments matching their schema:",
    toolSection,
    "",
    "Do not invent tool names. Do not claim an action succeeded yourself -- wait for a",
    "`zeroscript-result` block that the user's browser extension will paste back into the chat.",
    "If no result appears, the action has not happened yet.",
  ].join("\n");
}
