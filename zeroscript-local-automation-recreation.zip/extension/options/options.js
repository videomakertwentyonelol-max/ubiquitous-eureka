const bridgeUrlInput = document.getElementById("bridge-url");
const bridgeTokenInput = document.getElementById("bridge-token");
const savedMsg = document.getElementById("saved-msg");

chrome.runtime.sendMessage({ type: "GET_STATE" }, (resp) => {
  if (resp) bridgeUrlInput.value = resp.bridgeUrl || "";
});

document.getElementById("save-btn").addEventListener("click", () => {
  chrome.runtime.sendMessage(
    {
      type: "SET_CONFIG",
      bridgeUrl: bridgeUrlInput.value.trim() || "ws://127.0.0.1:8765/ws",
      token: bridgeTokenInput.value.trim(),
    },
    () => {
      savedMsg.style.display = "block";
      bridgeTokenInput.value = "";
      setTimeout(() => (savedMsg.style.display = "none"), 2000);
    }
  );
});
