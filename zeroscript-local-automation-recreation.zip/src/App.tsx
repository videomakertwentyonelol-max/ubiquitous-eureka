import { cn } from "./utils/cn";

type FileEntry = { path: string; note: string };

const components: {
  title: string;
  tagline: string;
  color: string;
  files: FileEntry[];
}[] = [
  {
    title: "1. Browser Extension",
    tagline: "Chrome/Edge Manifest V3 — detects completed tool-call blocks in an existing AI chat tab",
    color: "from-indigo-500 to-violet-600",
    files: [
      { path: "extension/manifest.json", note: "MV3 manifest, content script matches, permissions" },
      { path: "extension/background.js", note: "Owns the WebSocket to the bridge, confirmation gating" },
      { path: "extension/content/*.js", note: "Protocol parsing, dedupe, per-platform adapters, control bar" },
      { path: "extension/popup/*, extension/options/*", note: "Pairing, status, tool catalog, auto-submit toggle" },
    ],
  },
  {
    title: "2. Local Python Bridge",
    tagline: "aiohttp service on 127.0.0.1:8765 — validates and routes structured tool calls",
    color: "from-emerald-500 to-teal-600",
    files: [
      { path: "bridge/zeroscript_bridge/protocol.py", note: "Versioned JSON-Schema tool_call/tool_result contract" },
      { path: "bridge/zeroscript_bridge/security.py", note: "Origin/token auth, dedupe, size limits, redaction" },
      { path: "bridge/zeroscript_bridge/dispatcher.py", note: "Allowlist + schema + confirmation gate + routing" },
      { path: "bridge/zeroscript_bridge/integrations/*.py", note: "Roblox Studio, Blender, Sketchfab integrations" },
      { path: "bridge/tests/*", note: "Pytest suite: protocol, security, dispatcher, mocked integrations" },
    ],
  },
  {
    title: "3. MCP / Local Integrations",
    tagline: "Genuine, documented local connection mechanisms — no invented endpoints",
    color: "from-amber-500 to-orange-600",
    files: [
      { path: "roblox_plugin/ZeroScriptBridge.plugin.lua", note: "Studio plugin: HTTP long-poll, ChangeHistoryService undo" },
      { path: "blender_addon/zeroscript_blender_addon.py", note: "Blender add-on: local TCP JSON socket server" },
      { path: "blender_addon/PROTOCOL.md", note: "Documented wire protocol for the Blender socket" },
    ],
  },
];

const docs = [
  ["docs/README.md", "Documentation index & verification status"],
  ["docs/ARCHITECTURE.md", "Full data-flow diagram and request lifecycle"],
  ["docs/PROTOCOL.md", "The versioned structured tool-call protocol"],
  ["docs/INSTALL_WINDOWS.md", "Step-by-step Windows setup"],
  ["docs/ROBLOX_SETUP.md", "Roblox Studio plugin setup & limits"],
  ["docs/BLENDER_SETUP.md", "Blender add-on setup & limits"],
  ["docs/SKETCHFAB_SETUP.md", "Optional Sketchfab integration"],
  ["docs/SECURITY.md", "Security model and explicit boundaries"],
  ["docs/SUPPORTED_PLATFORMS.md", "Which AI chat sites have adapters"],
  ["docs/TROUBLESHOOTING.md", "Common failures and fixes"],
  ["docs/TESTING.md", "What's tested, mocked, and unverified"],
];

function Pill({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-full border border-slate-700 bg-slate-800/60 px-2.5 py-0.5 text-xs font-medium text-slate-300">
      {children}
    </span>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <div className="mx-auto max-w-5xl px-6 py-14">
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <Pill>Browser Extension</Pill>
          <Pill>Local Python Bridge</Pill>
          <Pill>MCP Integrations</Pill>
          <Pill>No paid AI API</Pill>
          <Pill>Loopback-only</Pill>
        </div>

        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">
          ZeroScript — Local AI-to-Tool Bridge
        </h1>
        <p className="mt-3 max-w-3xl text-slate-400">
          This project is a browser extension + a local Python bridge + MCP-style
          integration modules for Roblox Studio and Blender. It is intentionally{" "}
          <span className="text-slate-200 font-medium">not a website or hosted app</span> —
          this page is only a static, local index of what was generated, rendered
          here because this build environment can only preview a single web page.
          The real deliverables are the project folders listed below.
        </p>

        <div className="mt-10 rounded-xl border border-amber-800/40 bg-amber-950/30 p-4 text-sm text-amber-200">
          <strong>Nothing on this page is interactive or "live."</strong> It does
          not connect to the bridge, does not run in the extension, and does not
          represent the actual product UI (the product UI is the extension popup
          and its in-page control bar). Start with{" "}
          <code className="rounded bg-black/30 px-1 py-0.5">docs/README.md</code>{" "}
          in the project files.
        </div>

        <h2 className="mt-12 mb-4 text-xl font-semibold">The three required components</h2>
        <div className="grid gap-5 sm:grid-cols-1">
          {components.map((c) => (
            <div key={c.title} className="overflow-hidden rounded-xl border border-slate-800 bg-slate-900/60">
              <div className={cn("h-1.5 w-full bg-gradient-to-r", c.color)} />
              <div className="p-5">
                <h3 className="text-lg font-semibold">{c.title}</h3>
                <p className="mt-1 text-sm text-slate-400">{c.tagline}</p>
                <ul className="mt-4 space-y-2">
                  {c.files.map((f) => (
                    <li key={f.path} className="flex flex-col sm:flex-row sm:items-baseline sm:gap-3">
                      <code className="shrink-0 rounded bg-slate-800 px-1.5 py-0.5 text-xs text-emerald-300">
                        {f.path}
                      </code>
                      <span className="text-xs text-slate-500">{f.note}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        <h2 className="mt-12 mb-4 text-xl font-semibold">Quick start (Windows)</h2>
        <ol className="list-decimal space-y-2 pl-5 text-sm text-slate-300">
          <li>
            <code className="rounded bg-slate-800 px-1.5 py-0.5 text-emerald-300">
              bridge\scripts\install_windows.ps1
            </code>{" "}
            — creates a venv, installs deps, generates a safe default config + pairing token.
          </li>
          <li>
            <code className="rounded bg-slate-800 px-1.5 py-0.5 text-emerald-300">
              bridge\scripts\start_bridge.ps1
            </code>{" "}
            — starts the bridge on <code>127.0.0.1:8765</code>.
          </li>
          <li>Load <code className="rounded bg-slate-800 px-1.5 py-0.5">extension/</code> as an unpacked extension in Chrome/Edge, then pair it with the generated token.</li>
          <li>Add the extension's origin to <code className="rounded bg-slate-800 px-1.5 py-0.5">bridge/config/config.yaml</code>.</li>
          <li>Install the Roblox Studio plugin and/or the Blender add-on for the integrations you want.</li>
          <li>Open a supported AI chat site, start a session, and go.</li>
        </ol>

        <h2 className="mt-12 mb-4 text-xl font-semibold">Documentation</h2>
        <div className="grid gap-2 sm:grid-cols-2">
          {docs.map(([path, desc]) => (
            <div key={path} className="rounded-lg border border-slate-800 bg-slate-900/40 p-3">
              <code className="text-xs text-emerald-300">{path}</code>
              <p className="mt-1 text-xs text-slate-500">{desc}</p>
            </div>
          ))}
        </div>

        <footer className="mt-14 border-t border-slate-800 pt-6 text-xs text-slate-600">
          Independent functional recreation. No ZeroScript original source, assets,
          or branding were copied. See <code>docs/SECURITY.md</code> for the full
          security model and <code>docs/TESTING.md</code> for exactly what has and
          has not been verified.
        </footer>
      </div>
    </div>
  );
}
