# ZeroScript Blender Add-on Wire Protocol

Transport: plain TCP socket, bound to `127.0.0.1` by default on port `9877`
(configurable in both the add-on panel and `bridge/config/config.yaml`).

Framing: one JSON object per line (newline-delimited JSON, UTF-8). The
client sends exactly one request line and reads exactly one response line
per connection, then the connection is closed.

## Request

```json
{"type": "<action>", "params": { "...": "..." }}
```

## Response

Success:
```json
{"status": "ok", "result": { "...": "..." }}
```

Failure:
```json
{"status": "error", "message": "human-readable explanation"}
```

## Supported actions

| action              | params                                            | notes |
|---------------------|----------------------------------------------------|-------|
| `get_scene_info`    | `{}`                                               | read-only |
| `get_object_info`   | `{"name": str}`                                    | read-only |
| `create_object`     | `{"type": "CUBE"|"SPHERE"|"CYLINDER"|"PLANE"|"CONE"|"TORUS"|"EMPTY", "name"?: str, "location"?: [x,y,z], "rotation"?: [x,y,z], "scale"?: [x,y,z]}` | |
| `set_transform`     | `{"name": str, "location"?: [x,y,z], "rotation"?: [x,y,z], "scale"?: [x,y,z]}` | |
| `set_material_color`| `{"name": str, "material_name"?: str, "color": [r,g,b,a]}` | |
| `delete_object`     | `{"name": str}`                                    | |
| `execute_code`      | `{"code": str}`                                    | disabled unless the bridge config explicitly enables it; arbitrary code execution risk |

This protocol is an independent design created for this project. It is
intentionally similar in spirit (TCP + JSON + Blender add-on) to other
published Blender automation add-ons because that is the only practical,
documented way to reach Blender's scene from an external process -- Blender
does not expose a network API by default.
