# ZeroScript Blender Add-on

See [`docs/BLENDER_SETUP.md`](../docs/BLENDER_SETUP.md) for full setup
instructions, the tool list, and known limitations. Wire protocol is
documented in [`PROTOCOL.md`](PROTOCOL.md).

Quick version:

1. Blender > Edit > Preferences > Add-ons > Install... >
   `zeroscript_blender_addon.py`.
2. Enable **Interface: ZeroScript Bridge**.
3. Press `N` in the 3D viewport > **ZeroScript** tab > **Start Server**.
