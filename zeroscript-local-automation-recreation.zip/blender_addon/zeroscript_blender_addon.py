"""ZeroScript Blender Add-on.

Independent implementation (not copied from any third-party add-on). Opens
a local TCP socket server inside Blender so the ZeroScript Python bridge
(running as a separate OS process) can inspect and edit the current scene.

Wire protocol: newline-delimited JSON. See PROTOCOL.md in this folder.
Request:  {"type": "<action>", "params": {...}}\n
Response: {"status": "ok", "result": ...}\n   or
          {"status": "error", "message": "..."}\n

All Blender API calls are executed on Blender's main thread via
bpy.app.timers, because bpy is not thread-safe and the socket server runs
on a background thread.

Install:
  Blender > Edit > Preferences > Add-ons > Install... > select this file.
  Enable "Interface: ZeroScript Bridge".
  Open the 3D Viewport sidebar (press N) > "ZeroScript" tab > Start Server.

Security:
  - Binds to 127.0.0.1 only.
  - No authentication token at the TCP layer (same limitation documented by
    comparable community Blender MCP add-ons) -- do not expose this port
    beyond localhost. The ZeroScript bridge itself also never forwards
    blender.execute_code unless explicitly enabled in its own config.
"""

bl_info = {
    "name": "ZeroScript Bridge",
    "author": "ZeroScript (independent reimplementation)",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > ZeroScript",
    "description": "Local TCP bridge so the ZeroScript Python bridge can inspect/edit the scene",
    "category": "Interface",
}

import json
import queue
import socket
import threading
import traceback

import bpy  # noqa: E402

_server_socket = None
_server_thread = None
_stop_event = threading.Event()
_main_thread_queue: "queue.Queue" = queue.Queue()


# ---------------------------------------------------------------------------
# Command handlers (run on Blender's main thread)
# ---------------------------------------------------------------------------
def _obj_summary(obj):
    return {
        "name": obj.name,
        "type": obj.type,
        "location": list(obj.location),
        "rotation_euler": list(obj.rotation_euler),
        "scale": list(obj.scale),
    }


def handle_get_scene_info(params):
    scene = bpy.context.scene
    return {
        "scene_name": scene.name,
        "frame_start": scene.frame_start,
        "frame_end": scene.frame_end,
        "object_count": len(scene.objects),
        "objects": [_obj_summary(o) for o in scene.objects],
    }


def handle_get_object_info(params):
    name = params.get("name")
    obj = bpy.data.objects.get(name)
    if obj is None:
        raise ValueError(f"No object named '{name}'")
    info = _obj_summary(obj)
    if obj.type == "MESH" and obj.data is not None:
        info["mesh"] = {
            "vertices": len(obj.data.vertices),
            "edges": len(obj.data.edges),
            "polygons": len(obj.data.polygons),
        }
    info["materials"] = [m.name for m in obj.data.materials] if getattr(obj.data, "materials", None) else []
    return info


_PRIMITIVE_OPS = {
    "CUBE": lambda **kw: bpy.ops.mesh.primitive_cube_add(**kw),
    "SPHERE": lambda **kw: bpy.ops.mesh.primitive_uv_sphere_add(**kw),
    "CYLINDER": lambda **kw: bpy.ops.mesh.primitive_cylinder_add(**kw),
    "PLANE": lambda **kw: bpy.ops.mesh.primitive_plane_add(**kw),
    "CONE": lambda **kw: bpy.ops.mesh.primitive_cone_add(**kw),
    "TORUS": lambda **kw: bpy.ops.mesh.primitive_torus_add(**kw),
    "EMPTY": lambda **kw: bpy.ops.object.empty_add(**{k: v for k, v in kw.items() if k != "size"}),
}


def handle_create_object(params):
    obj_type = params.get("type")
    if obj_type not in _PRIMITIVE_OPS:
        raise ValueError(f"Unsupported primitive type '{obj_type}'")
    location = tuple(params.get("location", [0, 0, 0]))
    _PRIMITIVE_OPS[obj_type](location=location)
    obj = bpy.context.active_object
    if params.get("name"):
        obj.name = params["name"]
    if params.get("rotation"):
        obj.rotation_euler = tuple(params["rotation"])
    if params.get("scale"):
        obj.scale = tuple(params["scale"])
    return _obj_summary(obj)


def handle_set_transform(params):
    obj = bpy.data.objects.get(params.get("name"))
    if obj is None:
        raise ValueError(f"No object named '{params.get('name')}'")
    if "location" in params:
        obj.location = tuple(params["location"])
    if "rotation" in params:
        obj.rotation_euler = tuple(params["rotation"])
    if "scale" in params:
        obj.scale = tuple(params["scale"])
    return _obj_summary(obj)


def handle_set_material_color(params):
    obj = bpy.data.objects.get(params.get("name"))
    if obj is None:
        raise ValueError(f"No object named '{params.get('name')}'")
    mat_name = params.get("material_name") or f"{obj.name}_ZeroScriptMaterial"
    mat = bpy.data.materials.get(mat_name)
    if mat is None:
        mat = bpy.data.materials.new(name=mat_name)
        mat.use_nodes = True
    color = params.get("color", [0.8, 0.8, 0.8, 1.0])
    principled = mat.node_tree.nodes.get("Principled BSDF") if mat.use_nodes else None
    if principled is not None:
        principled.inputs["Base Color"].default_value = tuple(color)
    else:
        mat.diffuse_color = tuple(color)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)
    return {"object": obj.name, "material": mat.name, "color": color}


def handle_delete_object(params):
    obj = bpy.data.objects.get(params.get("name"))
    if obj is None:
        raise ValueError(f"No object named '{params.get('name')}'")
    name = obj.name
    bpy.data.objects.remove(obj, do_unlink=True)
    return {"deleted": name}


def handle_execute_code(params):
    # Gated on the bridge side (blender.allow_execute_code must be true).
    # Still documented here as high-risk: this executes arbitrary Python
    # with full access to the Blender process.
    code = params.get("code", "")
    local_ns = {"bpy": bpy, "result": None}
    exec(code, {"bpy": bpy}, local_ns)  # noqa: S102 - explicit, opt-in, documented risk
    return {"result": repr(local_ns.get("result"))}


HANDLERS = {
    "get_scene_info": handle_get_scene_info,
    "get_object_info": handle_get_object_info,
    "create_object": handle_create_object,
    "set_transform": handle_set_transform,
    "set_material_color": handle_set_material_color,
    "delete_object": handle_delete_object,
    "execute_code": handle_execute_code,
}


# ---------------------------------------------------------------------------
# Networking (background thread) <-> main thread bridging via timers
# ---------------------------------------------------------------------------
def _process_main_thread_queue():
    """Runs on Blender's main thread via bpy.app.timers."""
    try:
        while True:
            job = _main_thread_queue.get_nowait()
            request, respond = job
            try:
                action = request.get("type")
                handler = HANDLERS.get(action)
                if handler is None:
                    respond({"status": "error", "message": f"Unknown action '{action}'"})
                    continue
                result = handler(request.get("params") or {})
                respond({"status": "ok", "result": result})
            except Exception as exc:  # noqa: BLE001
                respond({"status": "error", "message": f"{exc}"})
                traceback.print_exc()
    except queue.Empty:
        pass
    return 0.05  # reschedule


def _handle_client(conn: socket.socket):
    with conn:
        conn.settimeout(30)
        buf = b""
        try:
            while True:
                chunk = conn.recv(65536)
                if not chunk:
                    return
                buf += chunk
                if b"\n" in buf:
                    break
            line, _, _rest = buf.partition(b"\n")
            request = json.loads(line.decode("utf-8"))
        except Exception as exc:  # noqa: BLE001
            try:
                conn.sendall((json.dumps({"status": "error", "message": f"bad request: {exc}"}) + "\n").encode("utf-8"))
            except Exception:
                pass
            return

        result_holder = {}
        event = threading.Event()

        def respond(payload):
            result_holder["payload"] = payload
            event.set()

        _main_thread_queue.put((request, respond))
        if not event.wait(timeout=30):
            result_holder["payload"] = {"status": "error", "message": "Blender main thread did not respond in time"}

        try:
            conn.sendall((json.dumps(result_holder["payload"]) + "\n").encode("utf-8"))
        except Exception:
            pass


def _server_loop(host, port):
    global _server_socket
    _server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    _server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    _server_socket.bind((host, port))
    _server_socket.listen(5)
    _server_socket.settimeout(1.0)
    while not _stop_event.is_set():
        try:
            conn, _addr = _server_socket.accept()
        except socket.timeout:
            continue
        except OSError:
            break
        threading.Thread(target=_handle_client, args=(conn,), daemon=True).start()


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------
class ZEROSCRIPT_OT_start_server(bpy.types.Operator):
    bl_idname = "zeroscript.start_server"
    bl_label = "Start ZeroScript Server"

    def execute(self, context):
        global _server_thread
        if _server_thread and _server_thread.is_alive():
            self.report({"INFO"}, "ZeroScript server already running")
            return {"CANCELLED"}
        _stop_event.clear()
        port = context.scene.zeroscript_port
        _server_thread = threading.Thread(target=_server_loop, args=("127.0.0.1", port), daemon=True)
        _server_thread.start()
        if not bpy.app.timers.is_registered(_process_main_thread_queue):
            bpy.app.timers.register(_process_main_thread_queue)
        self.report({"INFO"}, f"ZeroScript server listening on 127.0.0.1:{port}")
        return {"FINISHED"}


class ZEROSCRIPT_OT_stop_server(bpy.types.Operator):
    bl_idname = "zeroscript.stop_server"
    bl_label = "Stop ZeroScript Server"

    def execute(self, context):
        _stop_event.set()
        if _server_socket:
            try:
                _server_socket.close()
            except Exception:
                pass
        self.report({"INFO"}, "ZeroScript server stopped")
        return {"FINISHED"}


class ZEROSCRIPT_PT_panel(bpy.types.Panel):
    bl_label = "ZeroScript"
    bl_idname = "ZEROSCRIPT_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "ZeroScript"

    def draw(self, context):
        layout = self.layout
        layout.prop(context.scene, "zeroscript_port")
        running = bool(_server_thread and _server_thread.is_alive())
        layout.label(text=f"Status: {'Connected / Listening' if running else 'Stopped'}")
        if running:
            layout.operator(ZEROSCRIPT_OT_stop_server.bl_idname, text="Stop Server")
        else:
            layout.operator(ZEROSCRIPT_OT_start_server.bl_idname, text="Start Server")


classes = (
    ZEROSCRIPT_OT_start_server,
    ZEROSCRIPT_OT_stop_server,
    ZEROSCRIPT_PT_panel,
)


def register():
    bpy.types.Scene.zeroscript_port = bpy.props.IntProperty(
        name="Port", default=9877, min=1024, max=65535
    )
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    _stop_event.set()
    if _server_socket:
        try:
            _server_socket.close()
        except Exception:
            pass
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.zeroscript_port


if __name__ == "__main__":
    register()
