--!strict
--[[
    ZeroScript Bridge - Roblox Studio Plugin (independent implementation)

    WHAT THIS DOES
    Roblox Studio plugins can only make OUTBOUND HTTP requests (via
    HttpService); they cannot host a server or accept inbound connections.
    So this plugin repeatedly long-polls a local HTTP endpoint exposed by
    the ZeroScript Python bridge (127.0.0.1:8765 by default), executes any
    queued command against this place's DataModel, and posts the result
    back. This is the same constraint-driven pattern used by published
    community Roblox Studio MCP bridges; this file is an independent
    implementation written for this project.

    REQUIREMENTS
      1. Home > Game Settings > Security > "Allow HTTP Requests" = ON.
      2. The ZeroScript bridge must be running locally (see
         bridge/scripts/start_bridge.ps1) and its pairing token must match
         ZS_TOKEN below (copy it from bridge/config/bridge_token.txt).
      3. Install this file by renaming/placing it in your local Studio
         Plugins folder (Windows: %LOCALAPPDATA%\Roblox\Plugins) -- it must
         keep the ".plugin.lua" extension.

    SAFETY
      - Every consequential change (create/set/delete) is wrapped in a
        ChangeHistoryService waypoint so you can Ctrl+Z it.
      - "run_script" is NOT implemented by default. See the clearly marked
        section below if you choose to enable it yourself; doing so lets
        the bridge run arbitrary Luau in this place. That is a real risk
        and is off unless you edit this file.
]]

local HttpService = game:GetService("HttpService")
local ChangeHistoryService = game:GetService("ChangeHistoryService")
local RunService = game:GetService("RunService")

-- ===== User-configurable settings =====
local BRIDGE_BASE_URL = "http://127.0.0.1:8765"
local ZS_TOKEN = "PASTE_TOKEN_FROM_bridge_token.txt_HERE"
local ENABLE_RUN_SCRIPT = false -- matches bridge config roblox.allow_run_script
-- =======================================

local toolbar = plugin:CreateToolbar("ZeroScript")
local statusButton = toolbar:CreateButton(
    "ZeroScript Bridge",
    "Shows ZeroScript bridge connection status. Click to toggle polling.",
    "rbxassetid://0"
)
statusButton.ClickableWhenViewportHidden = true

local running = false
local connected = false

local function setStatus(text)
    statusButton:SetActive(connected)
    pcall(function()
        plugin:SetSetting("zeroscript_last_status", text)
    end)
end

-- ---- Path resolution -------------------------------------------------------
local function resolvePath(path: string): Instance?
    if path == nil or path == "" or path == "game" then
        return game
    end
    local segments = string.split(path, ".")
    local first = segments[1]
    if first == "game" then
        table.remove(segments, 1)
        first = segments[1]
    end
    local current: Instance = game
    if first ~= nil then
        local ok, service = pcall(function()
            return game:GetService(first)
        end)
        if ok and service then
            current = service
            table.remove(segments, 1)
        end
    end
    for _, seg in ipairs(segments) do
        if current == nil then
            return nil
        end
        current = current:FindFirstChild(seg)
    end
    return current
end

local function instancePath(inst: Instance): string
    local parts = {}
    local cur = inst
    while cur and cur ~= game do
        table.insert(parts, 1, cur.Name)
        cur = cur.Parent
    end
    return table.concat(parts, ".")
end

-- ---- Serialization helpers --------------------------------------------------
local function serializeValue(v: any): any
    local t = typeof(v)
    if t == "Vector3" then
        return { __type = "Vector3", x = v.X, y = v.Y, z = v.Z }
    elseif t == "CFrame" then
        local pos = v.Position
        return { __type = "CFrame", position = { pos.X, pos.Y, pos.Z } }
    elseif t == "Color3" then
        return { __type = "Color3", r = v.R, g = v.G, b = v.B }
    elseif t == "EnumItem" then
        return { __type = "EnumItem", name = v.Name, enum = tostring(v.EnumType) }
    elseif t == "BrickColor" then
        return { __type = "BrickColor", name = v.Name }
    elseif t == "Instance" then
        return { __type = "InstanceRef", path = instancePath(v) }
    elseif t == "table" then
        return v
    elseif t == "number" or t == "string" or t == "boolean" or v == nil then
        return v
    else
        return tostring(v)
    end
end

local function deserializeValue(v: any): any
    if type(v) == "table" and v.__type then
        if v.__type == "Vector3" then
            return Vector3.new(v.x, v.y, v.z)
        elseif v.__type == "Color3" then
            return Color3.new(v.r, v.g, v.b)
        elseif v.__type == "CFrame" then
            local p = v.position
            return CFrame.new(p[1], p[2], p[3])
        elseif v.__type == "BrickColor" then
            return BrickColor.new(v.name)
        end
    end
    return v
end

local function describeInstance(inst: Instance, path: string)
    return {
        name = inst.Name,
        class_name = inst.ClassName,
        path = path,
    }
end

-- ---- Command handlers --------------------------------------------------------
local function handleGetInstanceTree(params)
    local rootPath = params.root_path or "Workspace"
    local maxDepth = params.max_depth or 3
    local root = resolvePath(rootPath)
    if root == nil then
        error("No instance found at path '" .. rootPath .. "'")
    end

    local function walk(inst: Instance, path: string, depth: number)
        local node = describeInstance(inst, path)
        if depth < maxDepth then
            local children = {}
            for _, child in ipairs(inst:GetChildren()) do
                local childPath = path == "" and child.Name or (path .. "." .. child.Name)
                table.insert(children, walk(child, childPath, depth + 1))
            end
            node.children = children
        end
        return node
    end

    return walk(root, rootPath, 0)
end

local function handleGetProperties(params)
    local inst = resolvePath(params.path)
    if inst == nil then
        error("No instance found at path '" .. tostring(params.path) .. "'")
    end
    local names = params.property_names
    local out = {}
    if names and #names > 0 then
        for _, propName in ipairs(names) do
            local ok, value = pcall(function()
                return (inst :: any)[propName]
            end)
            if ok then
                out[propName] = serializeValue(value)
            end
        end
    else
        -- Minimal always-safe set when no explicit property list is given.
        local commonProps = { "Name", "ClassName", "Archivable" }
        for _, propName in ipairs(commonProps) do
            local ok, value = pcall(function()
                return (inst :: any)[propName]
            end)
            if ok then
                out[propName] = serializeValue(value)
            end
        end
    end
    return out
end

local function handleSetProperties(params)
    local inst = resolvePath(params.path)
    if inst == nil then
        error("No instance found at path '" .. tostring(params.path) .. "'")
    end
    ChangeHistoryService:SetWaypoint("ZeroScript: before set_properties on " .. params.path)
    for propName, value in pairs(params.properties or {}) do
        (inst :: any)[propName] = deserializeValue(value)
    end
    ChangeHistoryService:SetWaypoint("ZeroScript: set_properties on " .. params.path)
    return describeInstance(inst, params.path)
end

local function handleCreateInstance(params)
    local parent = resolvePath(params.parent_path)
    if parent == nil then
        error("No parent instance found at path '" .. tostring(params.parent_path) .. "'")
    end
    ChangeHistoryService:SetWaypoint("ZeroScript: before create_instance")
    local inst = Instance.new(params.class_name)
    if params.name then
        inst.Name = params.name
    end
    for propName, value in pairs(params.properties or {}) do
        local ok = pcall(function()
            (inst :: any)[propName] = deserializeValue(value)
        end)
        if not ok then
            warn("ZeroScript: failed to set property " .. propName .. " on new instance")
        end
    end
    inst.Parent = parent
    ChangeHistoryService:SetWaypoint("ZeroScript: create_instance " .. params.class_name)
    local path = instancePath(inst)
    return describeInstance(inst, path)
end

local function handleDeleteInstance(params)
    local inst = resolvePath(params.path)
    if inst == nil then
        error("No instance found at path '" .. tostring(params.path) .. "'")
    end
    ChangeHistoryService:SetWaypoint("ZeroScript: before delete_instance on " .. params.path)
    inst:Destroy()
    ChangeHistoryService:SetWaypoint("ZeroScript: delete_instance on " .. params.path)
    return { deleted = params.path }
end

local function handleRunScript(params)
    if not ENABLE_RUN_SCRIPT then
        error("run_script is disabled in this plugin. Set ENABLE_RUN_SCRIPT = true to enable it (not recommended).")
    end
    -- Intentionally left unimplemented by default. If you choose to enable
    -- this, you must supply your own sandboxed execution strategy; running
    -- arbitrary Luau from an AI-originated request is a real security risk.
    error("run_script execution path is not implemented in this reference plugin.")
end

local HANDLERS = {
    get_instance_tree = handleGetInstanceTree,
    get_properties = handleGetProperties,
    set_properties = handleSetProperties,
    create_instance = handleCreateInstance,
    delete_instance = handleDeleteInstance,
    run_script = handleRunScript,
}

-- ---- HTTP polling loop -------------------------------------------------------
local function postJson(path: string, body: table)
    local ok, response = pcall(function()
        return HttpService:PostAsync(
            BRIDGE_BASE_URL .. path .. "?token=" .. ZS_TOKEN,
            HttpService:JSONEncode(body),
            Enum.HttpContentType.ApplicationJson
        )
    end)
    if not ok then
        return nil, response
    end
    return response, nil
end

local function getJson(path: string)
    local ok, response = pcall(function()
        return HttpService:GetAsync(BRIDGE_BASE_URL .. path .. (path:find("?") and "&" or "?") .. "token=" .. ZS_TOKEN)
    end)
    if not ok then
        return nil, response
    end
    local decodeOk, decoded = pcall(function()
        return HttpService:JSONDecode(response)
    end)
    if not decodeOk then
        return nil, "invalid JSON from bridge"
    end
    return decoded, nil
end

local function sendHeartbeat()
    postJson("/integrations/roblox/heartbeat", {
        place_name = game.Name,
        place_id = game.PlaceId,
        studio_version = version(),
    })
end

local function pollLoop()
    while running do
        local body, err = getJson("/integrations/roblox/poll")
        if body == nil then
            connected = false
            setStatus("Disconnected: " .. tostring(err))
            task.wait(3)
        else
            connected = true
            setStatus("Connected")
            local command = body.command
            if command ~= nil then
                local handler = HANDLERS[command.action]
                local resultPayload
                if handler == nil then
                    resultPayload = { command_id = command.command_id, status = "error", message = "Unknown action: " .. tostring(command.action) }
                else
                    local ok, resultOrErr = pcall(handler, command.params or {})
                    if ok then
                        resultPayload = { command_id = command.command_id, status = "ok", result = resultOrErr }
                    else
                        resultPayload = { command_id = command.command_id, status = "error", message = tostring(resultOrErr) }
                    end
                end
                postJson("/integrations/roblox/result", resultPayload)
            end
        end
    end
end

local heartbeatConn
statusButton.Click:Connect(function()
    running = not running
    if running then
        setStatus("Starting...")
        sendHeartbeat()
        task.spawn(pollLoop)
        heartbeatConn = RunService.Heartbeat:Connect(function() end) -- placeholder keep-alive
        task.spawn(function()
            while running do
                sendHeartbeat()
                task.wait(10)
            end
        end)
    else
        setStatus("Stopped")
        if heartbeatConn then
            heartbeatConn:Disconnect()
        end
    end
end)

setStatus("Idle (click toolbar button to connect)")
