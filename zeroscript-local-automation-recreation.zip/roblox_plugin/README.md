# ZeroScript Roblox Studio Plugin

See [`docs/ROBLOX_SETUP.md`](../docs/ROBLOX_SETUP.md) for full setup
instructions, the tool list, and known limitations.

Quick version:

1. Enable **Allow HTTP Requests** (Home > Game Settings > Security).
2. Copy `ZeroScriptBridge.plugin.lua` into
   `%LOCALAPPDATA%\Roblox\Plugins`.
3. Edit the file and paste your bridge pairing token into `ZS_TOKEN`.
4. Restart Studio, open a place, click the **ZeroScript Bridge** toolbar
   button to start polling.
