#Requires -Version 5.1
<#
.SYNOPSIS
    Convenience wrapper: sets up the ZeroScript local bridge from the
    project root. See docs\INSTALL_WINDOWS.md for the full guide, including
    loading the browser extension and configuring Roblox Studio / Blender.
#>
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
powershell -ExecutionPolicy Bypass -File (Join-Path $Root "bridge\scripts\install_windows.ps1")
Write-Host ""
Write-Host "Next: read docs\INSTALL_WINDOWS.md, then run bridge\scripts\start_bridge.ps1" -ForegroundColor Cyan
