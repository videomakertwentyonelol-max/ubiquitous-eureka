# ZeroScript (independent recreation) — Documentation Index

ZeroScript connects an AI chat session you already have open in your own
browser to local developer tools (Roblox Studio, Blender, and optionally
Sketchfab) through:

1. **A browser extension** (`extension/`) — Manifest V3, Chrome/Edge.
2. **A local Python bridge** (`bridge/`) — runs on your PC, loopback-only.
3. **MCP-style integration modules** — a Roblox Studio Luau plugin
   (`roblox_plugin/`) and a Blender add-on (`blender_addon/`).

This is **not** a website, not a SaaS product, and does **not** call any
paid AI API. The AI inference happens entirely inside the chat website you
are already using in your browser; the bridge only validates and executes
already-structured tool-call requests.

## Documents

- [`ARCHITECTURE.md`](ARCHITECTURE.md) — how the three components fit together.
- [`PROTOCOL.md`](PROTOCOL.md) — the versioned structured tool-call protocol.
- [`INSTALL_WINDOWS.md`](INSTALL_WINDOWS.md) — step-by-step Windows setup.
- [`ROBLOX_SETUP.md`](ROBLOX_SETUP.md) — Roblox Studio plugin setup & limits.
- [`BLENDER_SETUP.md`](BLENDER_SETUP.md) — Blender add-on setup & limits.
- [`SKETCHFAB_SETUP.md`](SKETCHFAB_SETUP.md) — optional Sketchfab integration.
- [`SECURITY.md`](SECURITY.md) — the security model and its boundaries.
- [`SUPPORTED_PLATFORMS.md`](SUPPORTED_PLATFORMS.md) — exactly which AI chat
  sites have adapters, and their known fragility.
- [`TROUBLESHOOTING.md`](TROUBLESHOOTING.md) — common failures and fixes.
- [`TESTING.md`](TESTING.md) — what is automatically tested vs. what remains
  unverified in this environment.

## What is genuinely verified vs. not

This project was built and documented in an environment that can create
files and run `npm run build` for an unrelated static viewer page, but
**cannot** launch Roblox Studio, Blender, Chrome, or a Python interpreter.
That means:

- The protocol parsing, security controls, and dispatcher logic have
  **automated unit tests** (`bridge/tests/`) written against the real code,
  but those tests have not been executed in this environment — you must run
  `pytest` yourself (see `TESTING.md`).
- The Roblox Studio plugin and Blender add-on are real, complete
  implementations against documented mechanisms, but connecting them to a
  live Studio/Blender session has not been (and cannot be, here) verified
  end-to-end. You must verify this on your own Windows PC.
- The browser extension's DOM adapters use best-effort, layered selectors
  for chatgpt.com and claude.ai documented as of this writing; these sites
  change their markup periodically and the adapters may need updates (see
  `SUPPORTED_PLATFORMS.md`).
