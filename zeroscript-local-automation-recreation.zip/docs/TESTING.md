# Testing

## Automated tests included (mocked, no live external apps)

Location: `bridge/tests/`. Run with:

```powershell
cd bridge
.venv\Scripts\activate
pip install -r requirements.txt
pytest -v
```

| File | Covers |
|---|---|
| `test_protocol.py` | Structured protocol parsing: valid/invalid tool calls, hello messages, result formatting, protocol-version enforcement. |
| `test_security.py` | Origin allowlisting, token auth, redaction, duplicate-request protection (including TTL eviction), size limits. |
| `test_dispatcher.py` | End-to-end validation + routing against a `FakeIntegration` test double: allowlist rejection, schema rejection, confirmation-gate behavior, duplicate protection, and that integration-reported unavailability is surfaced rather than hidden. |
| `test_config.py` | Safe-default config generation is idempotent and loopback-only; token generation is stable across runs. |
| `test_roblox_integration_mock.py` | The Roblox integration's actual HTTP handlers (`aiohttp` test client) against a simulated plugin: heartbeat → poll → result round-trip, token enforcement, "not connected" failure path, `run_script` disabled-by-default path. |
| `test_blender_integration_mock.py` | The Blender integration's real TCP client code against a local fake TCP server implementing the documented wire protocol: success path, Blender-reported error path, fast failure when nothing is listening, `execute_code` disabled-by-default path. |

These are explicitly **mocked tests**: `test_roblox_integration_mock.py`
and `test_blender_integration_mock.py` do not launch Roblox Studio or
Blender. They verify that this project's own networking and protocol code
behaves correctly, using lightweight stand-ins for the external
application.

## What remains unverified (and why)

This generation environment can create/edit files and run `npm run build`
for an unrelated static documentation page, but it cannot:

- Execute `pytest` or any Python code (no Python runtime tool available
  here), so **the test suite above has not actually been run in this
  environment.** You must run it yourself on your Windows PC per the
  commands above.
- Launch a real Chrome/Edge browser session signed into chatgpt.com or
  claude.ai, so the extension's DOM adapters and the full
  extension-to-bridge WebSocket round trip have not been exercised
  end-to-end here.
- Launch Roblox Studio or Blender, so the Luau plugin and the Blender
  add-on have not been connected to a live application here.

## Recommended manual verification checklist (on your PC)

1. `pytest -v` inside `bridge/` — all tests should pass.
2. `bridge\scripts\start_bridge.ps1`, then open
   `http://127.0.0.1:8765/health` in a browser — should return JSON with a
   `tools` array.
3. Load the unpacked extension, pair it, confirm the popup dot turns green.
4. Open `chatgpt.com`, start a session, click "Insert Tool Instructions",
   send it, and ask a simple read-only question (e.g., "call
   roblox.get_instance_tree on Workspace"). Confirm a `zeroscript-tool`
   block appears and the control bar logs "Detected tool call...".
5. With Roblox Studio open, plugin installed, and polling, confirm the
   result block that gets pasted back contains a real instance tree (not an
   error).
6. Repeat with Blender open and its add-on server started, using
   `blender.get_scene_info`.
7. Try a consequential tool (e.g., `blender.create_object`) and confirm the
   approval prompt appears before anything happens, and that denying it
   produces a `user_denied` result without touching Blender.
