# Supported AI Chat Platforms

ZeroScript does **not** claim universal compatibility with every AI chat
website. Each platform requires its own adapter because DOM structure is
not standardized and changes over time.

## Implemented adapters

| Platform | Adapter file | Status |
|---|---|---|
| chatgpt.com / chat.openai.com | `extension/content/chatgpt_adapter.js` | Implemented with layered fallback selectors for the input box, send button, assistant message container, and streaming indicator. **Not verified against a live authenticated session in this environment** (no browser available here) — verify on your machine and expect to update selectors if OpenAI changes the UI. |
| claude.ai | `extension/content/claude_adapter.js` | Implemented with layered fallback selectors (`data-testid` based where documented, class-name based fallbacks). **Not verified against a live authenticated session in this environment.** |

## Not implemented

Any other AI chat website (Gemini, Copilot, local LLM UIs, etc.) has no
adapter and the extension will not inject a control bar or scan messages
there, because the manifest's `content_scripts.matches` list only includes
the two hosts above. Adding a new platform means writing a new adapter file
implementing `ZeroScriptBaseAdapter`'s interface
(`extension/content/base_adapter.js`) and registering its match pattern in
`extension/manifest.json`.

## Why "not verified" matters here

This project was generated in an environment that can create and edit
files and run a Node/Vite build for an unrelated static documentation page,
but cannot launch an actual Chrome/Edge browser session signed into
chatgpt.com or claude.ai, and cannot execute Python. That means:

- The JSON extraction, validation, and messaging logic between content
  script, background worker, and bridge is implemented according to the
  documented WebExtension APIs and has internally consistent, testable
  logic, but the live DOM selectors for each site could not be exercised
  against the real, current production page in this environment.
- You should load the extension, open DevTools on the target chat site, and
  confirm the selectors in the relevant adapter file still match before
  relying on automatic detection. If they don't, update the `*_SELECTORS`
  arrays — no other part of the system needs to change.

## Streaming / completion detection

Both adapters are intentionally conservative: if it is ambiguous whether a
message is still streaming, they treat it as streaming (i.e., do nothing)
rather than risk parsing a partial JSON block. The content script also
requires a message's text hash to stay stable for 700ms after the adapter
reports "not streaming" before it is parsed, as a second safeguard.
