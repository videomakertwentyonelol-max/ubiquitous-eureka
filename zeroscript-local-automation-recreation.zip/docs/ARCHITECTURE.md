# Architecture

```
┌─────────────────────────────┐        loopback WebSocket (ws://127.0.0.1:8765/ws)
│  Browser (Chrome/Edge)      │  <───────────────────────────────────────────┐
│  ┌────────────────────────┐│                                               │
│  │ AI chat tab (chatgpt/   ││   content script (DOM-scoped, per platform)  │
│  │ claude.ai) you are      ││───> parses completed assistant messages for  │
│  │ already signed into     ││     ```zeroscript-tool``` fenced JSON blocks │
│  └────────────────────────┘│                                               │
│  Extension background       │ <── forwards validated tool_call, receives   │
│  service worker              │     tool_result, relays back to content     │
└─────────────────────────────┘     script which pastes a                    │
                                     ```zeroscript-result``` block            │
                                     into the chat input box.                 │
                                                                               │
                                                                               ▼
┌───────────────────────────────────────────────────────────────────────────────┐
│ Local Python Bridge (bridge/zeroscript_bridge), 127.0.0.1:8765 only            │
│  - aiohttp server: /ws (extension), /health, /integrations/roblox/* (plugin)  │
│  - security.py: origin allowlist, token auth, size limits, dedupe             │
│  - protocol.py: strict JSON-Schema validation of tool_call/tool_result        │
│  - dispatcher.py: allowlist lookup, argument validation, confirmation gate    │
│  - tool_registry.py: built from each integration's declared tools            │
└───────────────────────────────────────────────────────────────────────────────┘
        │                                   │                           │
        ▼                                   ▼                           ▼
┌────────────────────┐          ┌─────────────────────┐      ┌─────────────────────┐
│ Roblox integration  │          │ Blender integration  │      │ Sketchfab (optional) │
│ HTTP long-poll       │          │ TCP JSON socket       │      │ HTTPS REST API v3     │
│ (127.0.0.1:8765/     │          │ client -> add-on on   │      │ client (search +      │
│ integrations/roblox) │          │ 127.0.0.1:9877        │      │ authorized download)  │
└─────────┬────────────┘          └──────────┬────────────┘      └─────────────────────┘
          │ polled by                         │ connects to
          ▼                                   ▼
┌───────────────────────┐          ┌───────────────────────────┐
│ roblox_plugin/*.lua    │          │ blender_addon/*.py         │
│ installed as a local   │          │ installed/enabled inside   │
│ Studio plugin           │          │ Blender (Preferences >     │
│ (outbound HTTP only,    │          │ Add-ons)                   │
│ per Studio's sandbox)   │          │                             │
└───────────────────────┘          └───────────────────────────┘
```

## Why this shape, specifically

- **Roblox Studio plugins cannot host a server.** The Luau sandbox only
  allows outbound `HttpService` calls (and only once "Allow HTTP Requests"
  is enabled). So the bridge hosts the server and the plugin polls it. This
  is the same constraint every community Roblox Studio MCP bridge works
  within; this project's implementation of that pattern is original.
- **Blender has no built-in network API.** An external Python process
  cannot reach into Blender's embedded interpreter without something
  running inside Blender to accept the connection. So this project ships
  its own small Blender add-on that opens a local TCP socket, and the
  bridge is a client to it.
- **The bridge never talks to a paid AI API**, and never fabricates a tool
  result — every result returned to the extension came from a real response
  from the Roblox plugin, the Blender add-on, or the Sketchfab REST API.
- **The extension never trusts the AI's text.** It only acts on a specific,
  versioned, schema-validated JSON block. Ordinary conversational text is
  never interpreted as a command.
- **The bridge re-validates everything independently of the extension** —
  allowlist, schema, size limits, duplicate protection, and confirmation
  requirements are all enforced server-side regardless of what the
  extension already checked.

## Request lifecycle (happy path)

1. User opens `chatgpt.com` (or `claude.ai`), signs in normally.
2. User starts `bridge/scripts/start_bridge.ps1`.
3. User loads the unpacked extension and pairs it (pastes the bridge's
   pairing token into the popup).
4. User clicks "Start Session" in the extension's in-page control bar, and
   optionally "Insert Tool Instructions" to tell the model about the
   protocol and current tool catalog.
5. User asks the AI to do something; the AI (if it follows the inserted
   instructions) replies with a ```` ```zeroscript-tool ```` fenced JSON block.
6. The content script waits until that message has fully finished
   streaming, extracts and validates the JSON, and forwards it to the
   background service worker.
7. The background worker checks whether the tool is consequential (from the
   live tool catalog advertised by the bridge in `hello_ack`); if so it asks
   the user to approve/deny inline in the control bar.
8. On approval (or immediately for non-consequential tools) the background
   worker sends `{"type": "tool_call", ...}` over the WebSocket to the
   bridge.
9. The bridge independently re-validates everything, checks the allowlist,
   checks confirmation, and dispatches to the right integration.
10. The integration performs the real operation (or reports a real error /
    unavailability) and the bridge returns a `zeroscript.tool_result/1`
    message.
11. The background worker relays that result to the originating tab, which
    pastes a ```` ```zeroscript-result ```` block into the chat input box so
    the user can send it back to the AI (or it auto-sends, if the user
    enabled that option).
