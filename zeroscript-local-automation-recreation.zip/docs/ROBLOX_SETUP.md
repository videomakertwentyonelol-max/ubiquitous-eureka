# Roblox Studio Integration Setup

## How it actually connects

Roblox Studio plugins run in a Luau sandbox that can only make **outbound**
HTTP requests via `HttpService` — they cannot accept inbound connections or
host a server. So:

- The **bridge** hosts a small local HTTP API
  (`http://127.0.0.1:8765/integrations/roblox/*`).
- The **Studio plugin** (`roblox_plugin/ZeroScriptBridge.plugin.lua`)
  repeatedly long-polls `GET /integrations/roblox/poll`. When the bridge has
  a queued tool call, the plugin executes it against the open place's
  DataModel using ordinary Luau/Instance APIs, wrapped in
  `ChangeHistoryService` waypoints so you can `Ctrl+Z` any change, and posts
  the result back to `POST /integrations/roblox/result`.

This is a genuine, verifiable mechanism — the same "local HTTP bridge +
polling plugin" pattern used by published community Roblox Studio MCP
projects — reimplemented independently for this project. It is **not** the
same as the official Studio MCP server built into Studio (which uses stdio
and is designed for IDE-style MCP clients, not a browser-driven workflow);
this project implements its own bridge specifically so a browser extension
can drive it.

## Setup steps

1. In Roblox Studio, open **Home > Game Settings > Security** and enable
   **Allow HTTP Requests**. This is required — the plugin cannot talk to
   the bridge otherwise.
2. Start the ZeroScript bridge (`bridge\scripts\start_bridge.ps1`).
3. Open `bridge\config\bridge_token.txt` and copy its contents.
4. Copy `roblox_plugin\ZeroScriptBridge.plugin.lua` into
   `%LOCALAPPDATA%\Roblox\Plugins` (create the folder if it does not exist;
   Studio also exposes this via **Plugins > Plugins Folder**).
5. Open the file in a text editor and paste your token into the
   `ZS_TOKEN` constant near the top (the plugin cannot read your filesystem
   token file directly — Luau plugins are sandboxed from arbitrary disk
   access).
6. Restart Roblox Studio (or reload the plugin), open any place, and click
   the **ZeroScript Bridge** toolbar button to start polling. It will report
   "Connected" once it successfully reaches the bridge.

## What is actually implemented

Read operations (safe, no confirmation required):
- `roblox.get_instance_tree` — list descendants under a path, bounded depth.
- `roblox.get_properties` — read named properties of one instance.

Write operations (consequential — require confirmation in the extension,
wrapped in undo waypoints):
- `roblox.set_properties`
- `roblox.create_instance`
- `roblox.delete_instance`

`roblox.run_script` (arbitrary Luau execution) is **not implemented** in
the reference plugin and is disabled by default on the bridge
(`roblox.allow_run_script: false`). The plugin file contains an explicit,
clearly marked stub that raises an error unless you choose to implement
execution yourself — this project does not ship arbitrary remote code
execution against your Roblox place by default.

## Known limitations

- Only one Studio place/session is tracked at a time by this reference
  implementation (the first one that starts polling). Running multiple
  Studio windows against one bridge instance is not supported here.
- Studio's tool surface is whatever this plugin implements — not Roblox's
  own (closed) in-Studio AI Assistant and not every API Roblox exposes.
  Treat the tool list in `ROBLOX_STUDIO_INTEGRATION`'s `list_tools()` as the
  single source of truth for what is genuinely available.
- If Studio is closed, crashes, or the plugin isn't polling, the bridge
  reports `integration_unavailable` with a specific, actionable message —
  it never fabricates a successful result.

## Diagnostics

`GET http://127.0.0.1:8765/health` (from a browser or curl) lists currently
registered tools. `GET http://127.0.0.1:8765/integrations/roblox/status?token=<token>`
reports whether the plugin's heartbeat is recent (i.e., genuinely
connected) and the last known place name/id.
