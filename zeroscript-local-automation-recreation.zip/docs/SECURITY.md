# Security Model

## Trust boundary

**Nothing coming from the AI chat website, the page DOM, or the extension
is trusted automatically.** The bridge re-validates everything itself,
independent of whatever the extension already checked. This is enforced in
`bridge/zeroscript_bridge/dispatcher.py` and `security.py`.

## Controls implemented

| Control | Where | Detail |
|---|---|---|
| Tool allowlisting | `tool_registry.py`, `dispatcher.py` | A tool must be registered by a started, enabled integration to be dispatched at all. Dangerous tools (`run_script`, `execute_code`) are only registered when explicitly enabled in `config.yaml`. |
| Argument schema validation | `dispatcher.py` via `jsonschema` | Every tool has a strict JSON Schema (`additionalProperties: false` where practical, length/size caps). |
| Request-size limits | `security.enforce_size_limit` | Both whole-message and arguments-only byte caps, configurable. |
| Timeouts | `dispatcher.py`, per-integration configs | A global per-call timeout plus integration-specific connect/command timeouts. |
| Duplicate-request protection | `security.DuplicateGuard` | A `request_id` can only be executed once within its TTL window; replays are rejected with `duplicate_request`. |
| Confirmation for consequential ops | `dispatcher.py` + extension UI | Tools marked `consequential=True` are refused with `confirmation_required` unless the caller sets `requires_confirmation: true`; the extension only sets that after an explicit user click, but the bridge enforces it even if the extension is bypassed entirely. |
| Loopback-only binding | `config.py` defaults, `server.py` | Bridge binds `127.0.0.1` by default; nothing here advertises itself to the LAN. |
| Extension origin validation | `security.check_origin` | The WebSocket handshake is rejected unless the `Origin` header matches a configured `chrome-extension://<id>` allowlist. Fails closed if unconfigured. |
| Pairing token / connection auth | `security.check_token`, `config.ensure_token` | A random local token is generated on first run and required in the WebSocket `hello` message. |
| Redacted logs | `security.redact`, `logging_setup.py` | Token/secret-shaped keys are redacted before logging; long strings are truncated. |
| Safe subprocess/path handling | Roblox/Blender integrations | No `subprocess` or filesystem path is built from unvalidated AI input; Sketchfab downloads sanitize the output filename. |
| Disconnected-integration handling | All integrations | Every integration call fails fast with a specific `integration_unavailable` error rather than hanging or pretending success. |

## What is explicitly NOT a security boundary

- **The Blender add-on's TCP socket has no authentication of its own** (a
  documented limitation shared with comparable community add-ons). Its
  safety comes entirely from binding to `127.0.0.1`. Do not port-forward or
  tunnel it.
- **`roblox.run_script` and `blender.execute_code` are real code execution
  if you turn them on.** They are off by default and require you to
  explicitly edit `config.yaml`. The Roblox plugin additionally ships with
  `run_script` unimplemented (a stub that errors) so enabling the bridge
  flag alone does not grant code execution — a second, independent switch
  would have to be built into the plugin.
- **The bridge cannot stop a user from manually pairing an untrusted
  extension build.** Only load the `extension/` folder from this project (or
  a build you've personally reviewed).

## Things this project explicitly does NOT do

- Does not read, store, or exfiltrate your AI chat account's password or
  authentication cookies. The extension only reads the visible text of
  completed assistant messages on pages you are already signed into, and
  types into the existing message box — the same as a human using the
  keyboard.
- Does not bypass CAPTCHAs, 2FA, or platform rate limits.
- Does not expose any port beyond `127.0.0.1` by default.
- Does not call any paid AI API; the bridge process never makes an
  inference request anywhere.
