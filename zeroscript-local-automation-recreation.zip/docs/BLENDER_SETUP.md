# Blender Integration Setup

## How it actually connects

Blender does not expose a network API by default, and an unrelated Python
process cannot reach into Blender's embedded interpreter without something
running inside Blender to accept the connection. So this project ships its
own Blender add-on (`blender_addon/zeroscript_blender_addon.py`) that opens
a plain TCP socket server bound to `127.0.0.1:9877` (configurable) when you
click "Start Server" in its panel. The bridge is a TCP client to that
add-on, speaking a small newline-delimited JSON protocol documented in
[`blender_addon/PROTOCOL.md`](../blender_addon/PROTOCOL.md).

This mirrors the two-process shape used by comparable published Blender
automation add-ons (an add-on socket server + an external client), because
that is the only practical way to reach Blender from outside — but the code
here is an independent implementation written for this project, not a copy
of any third-party add-on.

## Setup steps

1. Open Blender (3.0+).
2. **Edit > Preferences > Add-ons > Install...**, select
   `blender_addon/zeroscript_blender_addon.py`.
3. Enable the checkbox next to **Interface: ZeroScript Bridge**.
4. In the 3D Viewport, press `N` to open the sidebar, select the
   **ZeroScript** tab, confirm the port (default `9877` — matches
   `bridge/config/config.yaml`'s `blender.port`), and click **Start Server**.
5. Start the ZeroScript bridge if it isn't already running. No token is
   required at the Blender TCP layer (see Security notes below); the bridge
   enforces its own `blender.allow_execute_code` gating independently of
   Blender itself.

## What is actually implemented

Read operations (no confirmation required):
- `blender.get_scene_info` — object list, scene name, frame range.
- `blender.get_object_info` — transform, mesh stats, materials.

Write operations (consequential — require confirmation):
- `blender.create_object` (CUBE, SPHERE, CYLINDER, PLANE, CONE, TORUS, EMPTY)
- `blender.set_transform`
- `blender.set_material_color`
- `blender.delete_object`

`blender.execute_code` (arbitrary Python inside Blender) exists in the
add-on but is **disabled by default** on the bridge
(`blender.allow_execute_code: false`). If you intentionally enable it,
understand that it grants full Python execution inside your Blender
process — there is no sandboxing.

## Known limitations

- The add-on's socket has no authentication of its own (matching the same
  documented limitation of comparable community Blender MCP add-ons) — it
  relies entirely on binding to `127.0.0.1` only. Do not change the add-on
  or bridge to listen on a non-loopback address.
- One Blender instance per port. Running multiple Blender windows requires
  different ports configured on both the add-on panel and
  `bridge/config/config.yaml`.
- If Blender is closed or the add-on server isn't started, the bridge fails
  fast with a specific `integration_unavailable` message rather than
  pretending the operation worked.

## Diagnostics

`GET http://127.0.0.1:8765/health` lists whether `blender.*` tools are
registered. The bridge's `status()` check (surfaced through future
diagnostics endpoints/logs) performs a real TCP connect attempt to
`127.0.0.1:9877` and reports the real connection error if Blender isn't
reachable.
