# Sketchfab Integration Setup (optional)

This integration is independent of the core extension/bridge/Roblox/Blender
architecture. It is disabled by default (`sketchfab.enabled: false`).

## What it does

- `sketchfab.search_models` — searches Sketchfab's public model catalog via
  the official Data API v3 (`GET https://api.sketchfab.com/v3/search`). No
  authentication required for search.
- `sketchfab.download_model` (consequential) — requests an authorized
  download link via `GET https://api.sketchfab.com/v3/models/{uid}/download`
  using your personal API token, then downloads the returned archive to
  `sketchfab.download_dir` (default `bridge/downloads/sketchfab/`).

## Setup

1. Log into sketchfab.com, go to **Settings > Password & API**, and copy
   your personal API token.
2. Either:
   - set it in `bridge/config/config.yaml` under `sketchfab.api_token`, or
   - set the environment variable `ZEROSCRIPT_SKETCHFAB_TOKEN` before
     starting the bridge (preferred if you don't want the token on disk in
     plaintext).
3. Set `sketchfab.enabled: true` in `config.yaml`.
4. Restart the bridge.

## Respecting licenses and limits

- Only models marked `isDownloadable` by their owner can be downloaded;
  Sketchfab enforces this server-side regardless of what this integration
  does.
- Each model's `license` field is returned by `search_models` — check it
  before using an asset.
- Download links returned by Sketchfab are short-lived/single-use; this
  integration does not cache or redistribute them.
- This integration does not implement upload, comment, or account-write
  operations — only the two read/download actions listed above.
