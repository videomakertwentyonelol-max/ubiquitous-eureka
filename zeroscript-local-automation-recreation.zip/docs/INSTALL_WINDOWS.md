# Windows Installation Guide

Target: Windows 10/11. No administrator privileges required.

## 1. Prerequisites

- Python 3.10+ (https://www.python.org/downloads/windows/, check "Add to PATH").
- Google Chrome or Microsoft Edge (any recent version).
- Roblox Studio and/or Blender, if you intend to use those integrations.

## 2. Set up the local bridge

```powershell
cd bridge
powershell -ExecutionPolicy Bypass -File scripts\install_windows.ps1
```

This creates `bridge\.venv`, installs dependencies, and generates:
- `bridge\config\config.yaml` (safe local defaults — loopback-only, every
  dangerous tool disabled)
- `bridge\config\bridge_token.txt` (your pairing token — keep it local)

Edit `bridge\config\config.yaml`:
- Add your extension's `chrome-extension://<id>` origin under
  `security.allowed_extension_origins` (see step 4 below for how to find
  the id). The bridge refuses every connection until this is set.
- Leave `roblox.allow_run_script` and `blender.allow_execute_code` as
  `false` unless you specifically understand and accept that risk.

## 3. Start the bridge

```powershell
bridge\scripts\start_bridge.ps1
```
or double-click `bridge\scripts\start_bridge.bat`.

You should see log lines confirming it is listening on `127.0.0.1:8765`.
Leave this window open while you work; press `Ctrl+C` to shut it down
cleanly.

## 4. Load the browser extension

1. Open `chrome://extensions` (or `edge://extensions`).
2. Enable **Developer mode**.
3. Click **Load unpacked** and select the `extension/` folder.
4. Copy the generated extension ID shown on its card.
5. Paste `chrome-extension://<that id>` into
   `bridge\config\config.yaml` under `allowed_extension_origins`, then
   restart the bridge.
6. Click the ZeroScript icon in the toolbar, paste the token from
   `bridge\config\bridge_token.txt`, and click **Save & Connect**. The
   status dot should turn green within a couple of seconds.

## 5. Set up the application integrations you want

- Roblox Studio: see [`ROBLOX_SETUP.md`](ROBLOX_SETUP.md).
- Blender: see [`BLENDER_SETUP.md`](BLENDER_SETUP.md).
- Sketchfab (optional): see [`SKETCHFAB_SETUP.md`](SKETCHFAB_SETUP.md).

## 6. Use it

1. Open `chatgpt.com` or `claude.ai`, sign in normally.
2. Click the floating "ZeroScript" control bar bottom-right, click
   **Start Session**.
3. Click **Insert Tool Instructions** once at the start of a conversation,
   review the inserted text, and send it.
4. Ask the AI to inspect or modify your Roblox/Blender project. If it
   replies with a `zeroscript-tool` block, the extension will show a
   confirmation prompt for any consequential action, forward the request to
   the bridge, and paste the result back into the chat input for you to
   send.

## Shutdown

- Stop the bridge with `Ctrl+C` in its console window (clean shutdown;
  closes all connections and integration sockets).
- Click **Stop Session** in the extension control bar, or just close the
  tab — no background cloud service keeps running.

## Uninstall

- Remove the unpacked extension from `chrome://extensions`.
- Delete the `bridge\.venv` folder and the `bridge\config` folder if you
  want to remove local state (this also deletes your pairing token).
- Disable/remove the Blender add-on from Blender's Preferences > Add-ons.
- Delete `ZeroScriptBridge.plugin.lua` from
  `%LOCALAPPDATA%\Roblox\Plugins`.
