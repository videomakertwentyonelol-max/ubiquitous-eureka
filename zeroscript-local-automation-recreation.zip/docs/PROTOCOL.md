# ZeroScript Structured Tool-Call Protocol (v1)

Two message shapes, each carrying an explicit `protocol` field so future
versions can be introduced without ambiguity.

## 1. Tool call — `zeroscript.tool_call/1`

Produced by the AI (ideally following the instructions inserted via the
extension popup's "Insert Tool Instructions" button), embedded as a fenced
code block tagged `zeroscript-tool` in the chat response:

````
```zeroscript-tool
{
  "protocol": "zeroscript.tool_call/1",
  "request_id": "5c2c6e0e-21d8-4a9a-9f1c-9b0f6a9ab111",
  "tool": "roblox.get_instance_tree",
  "arguments": { "root_path": "Workspace", "max_depth": 2 },
  "requires_confirmation": false
}
```
````

Fields:

| field | type | required | notes |
|---|---|---|---|
| `protocol` | string | yes | must be exactly `zeroscript.tool_call/1` |
| `request_id` | string (UUIDv4) | yes | generated fresh per call; reused only when re-sending the same call after user confirmation |
| `tool` | string | yes | `"<integration>.<action>"`, must be in the bridge's live allowlist |
| `arguments` | object | yes | validated against that tool's JSON Schema |
| `requires_confirmation` | boolean | no | the AI should leave this `false`/absent; the extension sets it to `true` itself after the user approves a consequential action |
| `created_at` | string | no | advisory ISO-8601 timestamp |
| `source` | object | no | advisory `{platform, conversation_id}` |

No other fields are accepted — both the extension and the bridge reject
unknown fields.

## 2. Tool result — `zeroscript.tool_result/1`

Produced by the bridge, relayed by the extension back into the chat input
as a fenced `zeroscript-result` block so the AI can see what happened:

````
```zeroscript-result
{
  "protocol": "zeroscript.tool_result/1",
  "request_id": "5c2c6e0e-21d8-4a9a-9f1c-9b0f6a9ab111",
  "status": "ok",
  "result": { "name": "Workspace", "class_name": "Workspace", "children": [] },
  "duration_ms": 182.4
}
```
````

On failure, `status` is `"error"` and an `error: {code, message}` object is
present instead of `result`. Common `error.code` values:

| code | meaning |
|---|---|
| `tool_not_allowed` | tool name not in the bridge's current allowlist |
| `argument_validation_failed` | arguments failed the tool's JSON Schema |
| `confirmation_required` | consequential tool called without `requires_confirmation: true` |
| `duplicate_request` | this `request_id` was already executed once |
| `integration_unavailable` | the target application/plugin isn't connected |
| `timeout` | the tool call exceeded the configured timeout |
| `request_too_large` | arguments exceeded the configured size limit |
| `user_denied` | the user denied the confirmation prompt in the extension |
| `internal_error` | unexpected bridge-side failure |

## 3. Extension <-> bridge WebSocket envelope

Transport: a single WebSocket per browser, `ws://127.0.0.1:8765/ws` by
default (loopback only).

1. **Hello (client -> server)**, required as the first message:
   ```json
   {"protocol": "zeroscript.hello/1", "type": "hello", "token": "<pairing token>", "client_version": "1.0.0", "platform": "extension"}
   ```
2. **Hello ack (server -> client)**:
   ```json
   {"type": "hello_ack", "protocol": "zeroscript.hello/1", "session_id": "...", "bridge_version": "1.0.0", "tools": [ {"name": "...", "description": "...", "argument_schema": {...}, "consequential": false }, ... ] }
   ```
3. **Tool call (client -> server)**: the `zeroscript.tool_call/1` object
   above, wrapped with `"type": "tool_call"`.
4. **Tool result (server -> client)**: the `zeroscript.tool_result/1`
   object above.
5. **Ping/pong** keep-alive: `{"type": "ping"}` / `{"type": "pong", "t": ...}`.
6. **Protocol error (server -> client)**: `{"type": "error", "code": "...", "message": "...", "request_id": "..."?}`.

## Why a fenced code block, not "any text that looks like JSON"

A specific fence tag (`zeroscript-tool`) is a deliberate, narrow convention
that:

- is unlikely to appear in ordinary conversation,
- is easy to extract deterministically with a regular expression,
- lets a human visually confirm what the AI is requesting before it's acted on,
- and is rejected outright if it doesn't parse as JSON or fails schema
  validation — it is never "interpreted loosely."

This is the mechanism by which the extension "teaches" the AI about
ZeroScript: the user-triggered "Insert Tool Instructions" button pastes a
message describing this exact convention and the live tool catalog. There
is no way to guarantee compliance from a third-party chat product; this is
documented as a best-effort, user-controlled mechanism, not an automatic
guarantee.
