# Troubleshooting

## Extension popup shows "Not paired yet"
You haven't saved a pairing token. Open
`bridge/config/bridge_token.txt`, copy its contents, paste into the popup's
token field, click **Save & Connect**.

## Extension popup stays "Disconnected"
- Is the bridge process actually running (`start_bridge.ps1` window open,
  no errors)?
- Does `bridge/config/config.yaml`'s `allowed_extension_origins` include
  the exact `chrome-extension://<id>` shown at `chrome://extensions` for
  this unpacked load? (It changes if you remove and re-load the extension
  without a fixed key.)
- Check the bridge log window / `bridge/logs/bridge.log` for a line like
  `Rejected WS connection: ...` — it tells you exactly why.

## Nothing happens when the AI replies
- Did you click **Start Session** in the floating control bar on the chat
  page? Tool-call scanning is off until you do.
- Open the control bar's log panel (click the header to expand) — it logs
  "Ignored malformed zeroscript-tool block" if the AI's block didn't parse,
  which usually means the model didn't follow the exact JSON shape. Try
  re-sending the "Insert Tool Instructions" message.
- The site's DOM may not match the adapter's selectors after a UI update —
  see `SUPPORTED_PLATFORMS.md`.

## "confirmation_required" error appears even after I approved
This should not happen in normal operation — the extension resends the
same request with `requires_confirmation: true` after you click Approve.
If you see it, check the bridge log for the exact tool name and confirm it
is listed under `security.require_confirmation_for` in `config.yaml`
consistently with what the extension expects (`tools` list from
`hello_ack`, visible in the popup).

## Roblox tool calls return "Roblox Studio plugin is not connected"
- Confirm **Allow HTTP Requests** is enabled in Game Settings > Security.
- Confirm you pasted the current token into `ZS_TOKEN` inside
  `ZeroScriptBridge.plugin.lua` and that the file still ends in
  `.plugin.lua` inside `%LOCALAPPDATA%\Roblox\Plugins`.
- Click the **ZeroScript Bridge** toolbar button in Studio — polling only
  starts after you click it once per Studio session.
- Hit `http://127.0.0.1:8765/integrations/roblox/status?token=<token>` in a
  browser; `connected: false` with no recent heartbeat means Studio truly
  isn't reaching the bridge (check Studio's Output window for HTTP errors).

## Blender tool calls return "Could not connect to the Blender add-on"
- Is Blender open with the ZeroScript add-on enabled and **Start Server**
  clicked in its sidebar panel?
- Does the port in the add-on panel match `blender.port` in
  `bridge/config/config.yaml` (default `9877`)?
- Antivirus/firewall software occasionally blocks local loopback sockets —
  check for a block notification.

## Sketchfab download fails with 401/403
Your `sketchfab.api_token` (or `ZEROSCRIPT_SKETCHFAB_TOKEN`) is missing,
wrong, or the specific model isn't downloadable/licensed for you. Search
results include an `is_downloadable` field — check it before attempting a
download.

## I want to reset everything
Stop the bridge, delete `bridge/config/config.yaml` and
`bridge/config/bridge_token.txt`, and restart the bridge — it regenerates
safe defaults and a fresh token (you'll need to re-pair the extension and
update the Roblox plugin's `ZS_TOKEN`).
