"""Tests for the independent security controls layer."""
import time

import pytest

from zeroscript_bridge import security


def test_redact_hides_secret_keys():
    data = {"token": "abc123", "nested": {"api_key": "xyz"}, "ok": "visible"}
    redacted = security.redact(data)
    assert redacted["token"] == "***REDACTED***"
    assert redacted["nested"]["api_key"] == "***REDACTED***"
    assert redacted["ok"] == "visible"


def test_redact_truncates_long_strings():
    redacted = security.redact({"blob": "x" * 1000})
    assert redacted["blob"].endswith("...<truncated>")
    assert len(redacted["blob"]) < 1000


def test_check_origin_allows_configured_origin():
    security.check_origin("chrome-extension://abc", ["chrome-extension://abc"])


def test_check_origin_rejects_unconfigured_allowlist():
    with pytest.raises(security.OriginNotAllowed):
        security.check_origin("chrome-extension://abc", [])


def test_check_origin_rejects_mismatched_origin():
    with pytest.raises(security.OriginNotAllowed):
        security.check_origin("chrome-extension://evil", ["chrome-extension://abc"])


def test_check_token_accepts_matching_token():
    security.check_token("secret-token", "secret-token")


def test_check_token_rejects_wrong_token():
    with pytest.raises(security.AuthenticationFailed):
        security.check_token("wrong", "secret-token")


def test_check_token_rejects_missing_token():
    with pytest.raises(security.AuthenticationFailed):
        security.check_token(None, "secret-token")


def test_duplicate_guard_blocks_second_use():
    guard = security.DuplicateGuard(ttl_seconds=60)
    guard.check_and_record("req-1")
    with pytest.raises(security.DuplicateRequest):
        guard.check_and_record("req-1")


def test_duplicate_guard_allows_different_ids():
    guard = security.DuplicateGuard(ttl_seconds=60)
    guard.check_and_record("req-1")
    guard.check_and_record("req-2")  # should not raise


def test_duplicate_guard_evicts_after_ttl():
    guard = security.DuplicateGuard(ttl_seconds=0)
    guard.check_and_record("req-1")
    time.sleep(0.01)
    guard.check_and_record("req-1")  # ttl already expired -> allowed again


def test_enforce_size_limit_passes_under_limit():
    security.enforce_size_limit(b"small", max_bytes=10)


def test_enforce_size_limit_raises_over_limit():
    with pytest.raises(security.RequestTooLarge):
        security.enforce_size_limit(b"x" * 100, max_bytes=10)
