"""Tests for structured protocol parsing (mocked data only, no live services)."""
import pytest

from zeroscript_bridge import protocol


def _valid_call(**overrides):
    base = {
        "protocol": protocol.PROTOCOL_TOOL_CALL,
        "request_id": "11111111-1111-4111-8111-111111111111",
        "tool": "roblox.get_instance_tree",
        "arguments": {"root_path": "game.Workspace"},
    }
    base.update(overrides)
    return base


def test_parse_valid_tool_call():
    call = protocol.parse_tool_call(_valid_call())
    assert call.tool == "roblox.get_instance_tree"
    assert call.integration == "roblox"
    assert call.action == "get_instance_tree"
    assert call.arguments == {"root_path": "game.Workspace"}


def test_rejects_wrong_protocol_version():
    with pytest.raises(protocol.ProtocolError):
        protocol.parse_tool_call(_valid_call(protocol="zeroscript.tool_call/2"))


def test_rejects_malformed_request_id():
    with pytest.raises(protocol.ProtocolError):
        protocol.parse_tool_call(_valid_call(request_id="not-a-uuid"))


def test_rejects_bad_tool_name_shape():
    with pytest.raises(protocol.ProtocolError):
        protocol.parse_tool_call(_valid_call(tool="DROP TABLE"))


def test_rejects_extra_unknown_fields():
    payload = _valid_call()
    payload["extra_field_not_allowed"] = True
    with pytest.raises(protocol.ProtocolError):
        protocol.parse_tool_call(payload)


def test_rejects_non_dict_payload():
    with pytest.raises(protocol.ProtocolError):
        protocol.parse_tool_call("not a dict")  # type: ignore[arg-type]


def test_make_result_ok():
    result = protocol.make_result("11111111-1111-4111-8111-111111111111", "ok", result={"a": 1})
    assert result["status"] == "ok"
    assert result["result"] == {"a": 1}
    assert result["protocol"] == protocol.PROTOCOL_TOOL_RESULT


def test_make_result_error():
    result = protocol.make_result(
        "11111111-1111-4111-8111-111111111111", "error", error_code="x", error_message="y"
    )
    assert result["status"] == "error"
    assert result["error"] == {"code": "x", "message": "y"}


def test_parse_hello_valid():
    hello = protocol.parse_hello(
        {
            "protocol": protocol.PROTOCOL_HELLO,
            "type": "hello",
            "token": "a" * 20,
            "client_version": "1.0.0",
        }
    )
    assert hello["token"] == "a" * 20


def test_parse_hello_rejects_short_token():
    with pytest.raises(protocol.ProtocolError):
        protocol.parse_hello(
            {
                "protocol": protocol.PROTOCOL_HELLO,
                "type": "hello",
                "token": "short",
                "client_version": "1.0.0",
            }
        )
