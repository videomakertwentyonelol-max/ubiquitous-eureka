"""Tests for request validation and routing. Uses a mocked integration --
no real Roblox Studio or Blender process is required."""
import pytest

from zeroscript_bridge.config import BridgeConfig
from zeroscript_bridge.dispatcher import Dispatcher
from zeroscript_bridge.integrations.base import Integration, IntegrationUnavailable, ToolSpec
from zeroscript_bridge.protocol import parse_tool_call
from zeroscript_bridge.tool_registry import ToolRegistry


class FakeIntegration(Integration):
    name = "fake"

    def __init__(self):
        self.calls = []
        self.fail_with: Exception | None = None

    async def start(self):
        pass

    async def stop(self):
        pass

    def list_tools(self):
        return [
            ToolSpec(
                name="fake.safe_echo",
                description="Echo back the arguments (not consequential).",
                argument_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["message"],
                    "properties": {"message": {"type": "string", "maxLength": 100}},
                },
            ),
            ToolSpec(
                name="fake.dangerous_delete",
                description="Pretend to delete something (consequential).",
                consequential=True,
                argument_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["path"],
                    "properties": {"path": {"type": "string"}},
                },
            ),
        ]

    async def status(self):
        return {"connected": True}

    async def call_tool(self, action, arguments):
        self.calls.append((action, arguments))
        if self.fail_with:
            raise self.fail_with
        if action == "safe_echo":
            return {"echo": arguments["message"]}
        if action == "dangerous_delete":
            return {"deleted": arguments["path"]}
        raise ValueError("unknown action")


def make_dispatcher():
    config = BridgeConfig(token="x" * 20)
    registry = ToolRegistry()
    fake = FakeIntegration()
    registry.rebuild([fake])
    return Dispatcher(config, registry), fake


def _call(tool, arguments, request_id="11111111-1111-4111-8111-111111111111", requires_confirmation=False):
    return parse_tool_call(
        {
            "protocol": "zeroscript.tool_call/1",
            "request_id": request_id,
            "tool": tool,
            "arguments": arguments,
            "requires_confirmation": requires_confirmation,
        }
    )


@pytest.mark.asyncio
async def test_dispatch_valid_safe_tool():
    dispatcher, fake = make_dispatcher()
    result = await dispatcher.dispatch(_call("fake.safe_echo", {"message": "hi"}))
    assert result["status"] == "ok"
    assert result["result"] == {"echo": "hi"}
    assert fake.calls == [("safe_echo", {"message": "hi"})]


@pytest.mark.asyncio
async def test_dispatch_unknown_tool_rejected():
    dispatcher, fake = make_dispatcher()
    result = await dispatcher.dispatch(_call("fake.not_registered", {}))
    assert result["status"] == "error"
    assert result["error"]["code"] == "tool_not_allowed"
    assert fake.calls == []


@pytest.mark.asyncio
async def test_dispatch_invalid_arguments_rejected():
    dispatcher, fake = make_dispatcher()
    result = await dispatcher.dispatch(_call("fake.safe_echo", {"wrong_field": 1}))
    assert result["status"] == "error"
    assert result["error"]["code"] == "argument_validation_failed"
    assert fake.calls == []


@pytest.mark.asyncio
async def test_consequential_tool_requires_confirmation_first():
    dispatcher, fake = make_dispatcher()
    result = await dispatcher.dispatch(_call("fake.dangerous_delete", {"path": "a"}, requires_confirmation=False))
    assert result["status"] == "error"
    assert result["error"]["code"] == "confirmation_required"
    assert fake.calls == []


@pytest.mark.asyncio
async def test_consequential_tool_runs_after_confirmation():
    dispatcher, fake = make_dispatcher()
    result = await dispatcher.dispatch(
        _call("fake.dangerous_delete", {"path": "a"}, request_id="22222222-2222-4222-8222-222222222222", requires_confirmation=True)
    )
    assert result["status"] == "ok"
    assert fake.calls == [("dangerous_delete", {"path": "a"})]


@pytest.mark.asyncio
async def test_duplicate_request_id_rejected_second_time():
    dispatcher, fake = make_dispatcher()
    rid = "33333333-3333-4333-8333-333333333333"
    first = await dispatcher.dispatch(_call("fake.safe_echo", {"message": "a"}, request_id=rid))
    second = await dispatcher.dispatch(_call("fake.safe_echo", {"message": "a"}, request_id=rid))
    assert first["status"] == "ok"
    assert second["status"] == "error"
    assert second["error"]["code"] == "duplicate_request"
    assert len(fake.calls) == 1


@pytest.mark.asyncio
async def test_integration_unavailable_is_surfaced_not_hidden():
    dispatcher, fake = make_dispatcher()
    fake.fail_with = IntegrationUnavailable("Roblox Studio plugin is not connected.")
    result = await dispatcher.dispatch(_call("fake.safe_echo", {"message": "a"}))
    assert result["status"] == "error"
    assert result["error"]["code"] == "integration_unavailable"
    assert "not connected" in result["error"]["message"]
