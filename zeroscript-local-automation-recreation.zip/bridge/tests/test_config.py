"""Tests for local configuration loading and safe-default generation."""
from pathlib import Path

from zeroscript_bridge import config as config_mod


def test_generate_default_config_creates_file(tmp_path: Path):
    cfg_path = tmp_path / "config.yaml"
    config_mod.ensure_token(tmp_path / "bridge_token.txt")
    result_path = config_mod.generate_default_config(cfg_path)
    assert result_path == cfg_path
    assert cfg_path.exists()
    text = cfg_path.read_text(encoding="utf-8")
    assert "127.0.0.1" in text
    assert "allow_run_script: false" in text


def test_generate_default_config_is_idempotent(tmp_path: Path):
    cfg_path = tmp_path / "config.yaml"
    config_mod.generate_default_config(cfg_path)
    first = cfg_path.read_text(encoding="utf-8")
    config_mod.generate_default_config(cfg_path)
    second = cfg_path.read_text(encoding="utf-8")
    assert first == second


def test_ensure_token_is_stable_across_calls(tmp_path: Path):
    token_file = tmp_path / "token.txt"
    t1 = config_mod.ensure_token(token_file)
    t2 = config_mod.ensure_token(token_file)
    assert t1 == t2
    assert len(t1) >= 20


def test_load_config_defaults_are_loopback_only(tmp_path: Path, monkeypatch):
    cfg_path = tmp_path / "config.yaml"
    monkeypatch.setenv("ZEROSCRIPT_BRIDGE_TOKEN", "test-token-0123456789")
    cfg = config_mod.load_config(cfg_path)
    assert cfg.security.bind_host == "127.0.0.1"
    assert cfg.roblox.allow_run_script is False
    assert cfg.blender.allow_execute_code is False
    assert cfg.sketchfab.enabled is False
