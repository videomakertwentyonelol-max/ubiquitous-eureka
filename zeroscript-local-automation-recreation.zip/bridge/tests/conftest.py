import pathlib
import sys

# Make the bridge package importable when running `pytest` from bridge/.
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
