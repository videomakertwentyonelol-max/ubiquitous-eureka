"""Mocked tests for the Roblox Studio integration's HTTP long-poll endpoints.

These tests exercise the bridge's own HTTP handlers using aiohttp's test
utilities and a simulated "plugin" HTTP client. They do NOT launch real
Roblox Studio -- that remains an external, unverified dependency documented
in docs/ROBLOX_SETUP.md and must be checked manually on a machine with
Studio installed.
"""
import asyncio

import pytest
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

from zeroscript_bridge.config import RobloxConfig
from zeroscript_bridge.integrations.base import IntegrationUnavailable
from zeroscript_bridge.integrations.roblox_studio import RobloxStudioIntegration


async def _make_client():
    config = RobloxConfig(poll_timeout_seconds=2, command_timeout_seconds=2)
    integration = RobloxStudioIntegration(config, bridge_token="test-token")
    app = web.Application()
    integration.register_http_routes(app)
    server = TestServer(app)
    client = TestClient(server)
    await client.start_server()
    return integration, client


@pytest.mark.asyncio
async def test_call_tool_fails_when_plugin_never_connected():
    integration, client = await _make_client()
    try:
        with pytest.raises(IntegrationUnavailable, match="not connected"):
            await integration.call_tool("get_instance_tree", {})
    finally:
        await client.close()


@pytest.mark.asyncio
async def test_heartbeat_then_poll_then_result_roundtrip():
    integration, client = await _make_client()
    try:
        # Simulate the Studio plugin's heartbeat.
        resp = await client.post(
            "/integrations/roblox/heartbeat?token=test-token",
            json={"place_name": "MyPlace", "place_id": 123},
        )
        assert resp.status == 200

        async def fake_plugin_loop():
            poll_resp = await client.get("/integrations/roblox/poll?token=test-token")
            body = await poll_resp.json()
            command = body["command"]
            assert command is not None
            assert command["action"] == "get_instance_tree"
            result_resp = await client.post(
                "/integrations/roblox/result?token=test-token",
                json={"command_id": command["command_id"], "status": "ok", "result": {"tree": []}},
            )
            assert result_resp.status == 200

        plugin_task = asyncio.create_task(fake_plugin_loop())
        result = await integration.call_tool("get_instance_tree", {"root_path": "game"})
        await plugin_task
        assert result == {"tree": []}
    finally:
        await client.close()


@pytest.mark.asyncio
async def test_poll_requires_valid_token():
    integration, client = await _make_client()
    try:
        resp = await client.get("/integrations/roblox/poll?token=wrong")
        assert resp.status == 401
    finally:
        await client.close()


@pytest.mark.asyncio
async def test_run_script_blocked_when_not_allowed_in_config():
    integration, client = await _make_client()
    try:
        await client.post("/integrations/roblox/heartbeat?token=test-token", json={})
        with pytest.raises(IntegrationUnavailable, match="disabled"):
            await integration.call_tool("run_script", {"code": "print('hi')"})
    finally:
        await client.close()
