"""Mocked tests for the Blender TCP integration using a fake local socket
server that imitates the documented wire protocol from
blender_addon/PROTOCOL.md. Does NOT launch real Blender -- verifying the
actual add-on requires a machine with Blender installed (see
docs/BLENDER_SETUP.md)."""
import asyncio
import json

import pytest

from zeroscript_bridge.config import BlenderConfig
from zeroscript_bridge.integrations.base import IntegrationUnavailable
from zeroscript_bridge.integrations.blender import BlenderIntegration


async def _start_fake_blender_server(response: dict, host="127.0.0.1"):
    async def handle(reader, writer):
        line = await reader.readline()
        json.loads(line.decode("utf-8"))  # ensure it's valid JSON we received
        writer.write((json.dumps(response) + "\n").encode("utf-8"))
        await writer.drain()
        writer.close()

    server = await asyncio.start_server(handle, host, 0)
    port = server.sockets[0].getsockname()[1]
    return server, port


@pytest.mark.asyncio
async def test_call_tool_succeeds_against_fake_server():
    server, port = await _start_fake_blender_server({"status": "ok", "result": {"objects": ["Cube"]}})
    try:
        config = BlenderConfig(port=port)
        integration = BlenderIntegration(config)
        result = await integration.call_tool("get_scene_info", {})
        assert result == {"objects": ["Cube"]}
    finally:
        server.close()
        await server.wait_closed()


@pytest.mark.asyncio
async def test_call_tool_surfaces_blender_error():
    server, port = await _start_fake_blender_server({"status": "error", "message": "no object named Foo"})
    try:
        config = BlenderConfig(port=port)
        integration = BlenderIntegration(config)
        with pytest.raises(IntegrationUnavailable, match="no object named Foo"):
            await integration.call_tool("get_object_info", {"name": "Foo"})
    finally:
        server.close()
        await server.wait_closed()


@pytest.mark.asyncio
async def test_call_tool_fails_fast_when_blender_not_running():
    config = BlenderConfig(host="127.0.0.1", port=1, connect_timeout_seconds=1)
    integration = BlenderIntegration(config)
    with pytest.raises(IntegrationUnavailable, match="Could not connect"):
        await integration.call_tool("get_scene_info", {})


@pytest.mark.asyncio
async def test_execute_code_blocked_unless_enabled():
    config = BlenderConfig(allow_execute_code=False)
    integration = BlenderIntegration(config)
    with pytest.raises(IntegrationUnavailable, match="disabled"):
        await integration.call_tool("execute_code", {"code": "1+1"})
