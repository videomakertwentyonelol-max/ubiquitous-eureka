"""Local aiohttp server: WebSocket endpoint for the browser extension plus
the Roblox Studio long-poll HTTP endpoints.

Binds to 127.0.0.1 only by default (never 0.0.0.0), per the loopback-only
requirement. The WebSocket route validates the Origin header against the
configured extension allowlist and requires a pairing token in the first
"hello" message before accepting any tool calls.
"""
from __future__ import annotations

import asyncio
import json
import logging
import signal
import time

from aiohttp import WSMsgType, web

from . import protocol
from .config import BridgeConfig, load_config
from .dispatcher import Dispatcher
from .integrations.blender import BlenderIntegration
from .integrations.roblox_studio import RobloxStudioIntegration
from .integrations.sketchfab import SketchfabIntegration
from .logging_setup import setup_logging
from .security import AuthenticationFailed, OriginNotAllowed, check_origin, check_token, enforce_size_limit, redact
from .session import SessionManager
from .tool_registry import ToolRegistry

logger = logging.getLogger("zeroscript.server")


class BridgeApp:
    def __init__(self, config: BridgeConfig):
        self.config = config
        self.sessions = SessionManager()
        self.registry = ToolRegistry()
        self.dispatcher = Dispatcher(config, self.registry)

        self.roblox = RobloxStudioIntegration(config.roblox, config.token)
        self.blender = BlenderIntegration(config.blender)
        self.sketchfab = SketchfabIntegration(config.sketchfab)
        self.integrations = [self.roblox, self.blender, self.sketchfab]

        self.app = web.Application(client_max_size=config.security.max_message_bytes + 4096)
        self.app.router.add_get("/health", self._handle_health)
        self.app.router.add_get("/ws", self._handle_ws)
        self.roblox.register_http_routes(self.app)
        self.app.on_startup.append(self._on_startup)
        self.app.on_cleanup.append(self._on_cleanup)

    async def _on_startup(self, app: web.Application) -> None:
        for integration in self.integrations:
            try:
                await integration.start()
            except Exception:
                logger.exception("Failed to start integration %s", integration.name)
        self.registry.rebuild(self.integrations)
        logger.info("Registered tools: %s", [t["name"] for t in self.registry.list_public()])

    async def _on_cleanup(self, app: web.Application) -> None:
        for integration in self.integrations:
            try:
                await integration.stop()
            except Exception:
                logger.exception("Failed to stop integration %s", integration.name)

    async def _handle_health(self, request: web.Request) -> web.Response:
        return web.json_response(
            {
                "status": "ok",
                "service": "zeroscript-bridge",
                "version": "1.0.0",
                "tools": [t["name"] for t in self.registry.list_public()],
                "active_sessions": len(self.sessions.all()),
            }
        )

    async def _handle_ws(self, request: web.Request) -> web.StreamResponse:
        origin = request.headers.get("Origin")
        try:
            check_origin(origin, self.config.security.allowed_extension_origins)
        except OriginNotAllowed as exc:
            logger.warning("Rejected WS connection: %s", exc)
            return web.json_response({"error": str(exc)}, status=403)

        ws = web.WebSocketResponse(max_msg_size=self.config.security.max_message_bytes, heartbeat=20)
        await ws.prepare(request)

        session = None
        authenticated = False

        async for msg in ws:
            if msg.type == WSMsgType.TEXT:
                try:
                    enforce_size_limit(msg.data.encode("utf-8"), self.config.security.max_message_bytes)
                    data = json.loads(msg.data)
                except Exception as exc:  # noqa: BLE001
                    await self._send_error(ws, None, "invalid_json", str(exc))
                    continue

                msg_type = data.get("type")

                if not authenticated:
                    if msg_type != "hello":
                        await self._send_error(ws, None, "not_authenticated", "First message must be 'hello'")
                        continue
                    try:
                        hello = protocol.parse_hello(data)
                        check_token(hello.get("token"), self.config.token)
                    except (protocol.ProtocolError, AuthenticationFailed) as exc:
                        await self._send_error(ws, None, "authentication_failed", str(exc))
                        await ws.close()
                        break
                    session = self.sessions.create(
                        client_version=hello.get("client_version", "unknown"),
                        platform=hello.get("platform", "unknown"),
                    )
                    authenticated = True
                    await ws.send_json(
                        {
                            "type": "hello_ack",
                            "protocol": protocol.PROTOCOL_HELLO,
                            "session_id": session.session_id,
                            "bridge_version": "1.0.0",
                            "tools": self.registry.list_public(),
                        }
                    )
                    logger.info("Extension session started: %s (%s)", session.session_id, session.platform)
                    continue

                if msg_type == "ping":
                    await ws.send_json({"type": "pong", "t": time.time()})
                    continue

                if msg_type == "tool_call":
                    session.touch()
                    try:
                        call = protocol.parse_tool_call(data)
                    except protocol.ProtocolError as exc:
                        await self._send_error(ws, data.get("request_id"), exc.code, exc.message)
                        continue
                    logger.debug("Received tool_call: %s", redact(data))
                    result = await self.dispatcher.dispatch(call)
                    session.tool_calls_handled += 1
                    await ws.send_json(result)
                    continue

                await self._send_error(ws, data.get("request_id"), "unknown_message_type", f"Unknown type '{msg_type}'")

            elif msg.type in (WSMsgType.ERROR, WSMsgType.CLOSE, WSMsgType.CLOSING, WSMsgType.CLOSED):
                break

        if session is not None:
            logger.info("Extension session ended: %s", session.session_id)
            self.sessions.drop(session.session_id)
        return ws

    async def _send_error(self, ws: web.WebSocketResponse, request_id: str | None, code: str, message: str) -> None:
        payload = {"type": "error", "code": code, "message": message}
        if request_id:
            payload["request_id"] = request_id
        await ws.send_json(payload)


def build_app(config: BridgeConfig | None = None) -> tuple[web.Application, BridgeConfig]:
    config = config or load_config()
    setup_logging(config.log_dir, config.log_level)
    bridge = BridgeApp(config)
    return bridge.app, config


def run() -> None:
    app, config = build_app()
    logger.info("ZeroScript bridge starting on %s:%s (loopback only)", config.security.bind_host, config.security.port)
    logger.info("Pairing token file: bridge/config/bridge_token.txt (paste into the extension options page)")
    web.run_app(app, host=config.security.bind_host, port=config.security.port, print=None)


if __name__ == "__main__":
    run()
