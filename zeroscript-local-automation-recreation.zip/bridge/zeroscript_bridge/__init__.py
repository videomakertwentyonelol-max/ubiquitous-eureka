"""ZeroScript Local Bridge.

An independent, local-only Python bridge that connects a browser extension
(running in the user's own browser, attached to an AI chat site the user is
already signed into) to local developer tools via the Model Context Protocol
(MCP) and documented local integration mechanisms (Roblox Studio HTTP
long-poll bridge, a local Blender TCP add-on, Sketchfab's REST API).

This package performs NO AI inference itself. It never contacts a paid
model API. It only validates and routes already-structured tool-call
requests that were produced by the user's existing AI chat session.
"""

__version__ = "1.0.0"
