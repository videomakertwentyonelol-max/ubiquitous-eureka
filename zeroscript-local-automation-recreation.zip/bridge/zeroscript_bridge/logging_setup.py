"""Logging configuration with redaction of likely-sensitive fields."""
from __future__ import annotations

import logging
import logging.handlers
import pathlib


def setup_logging(log_dir: str, level: str = "INFO") -> None:
    log_path = pathlib.Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)

    root = logging.getLogger("zeroscript")
    root.setLevel(level.upper())
    root.handlers.clear()

    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s")

    console = logging.StreamHandler()
    console.setFormatter(fmt)
    root.addHandler(console)

    file_handler = logging.handlers.RotatingFileHandler(
        log_path / "bridge.log", maxBytes=2_000_000, backupCount=5, encoding="utf-8"
    )
    file_handler.setFormatter(fmt)
    root.addHandler(file_handler)

    # Never log tokens/secrets even at DEBUG. Individual modules redact
    # structured payloads with security.redact(); this filter is a second
    # line of defense against accidental raw logging.
    class _RedactFilter(logging.Filter):
        def filter(self, record: logging.LogRecord) -> bool:
            msg = record.getMessage().lower()
            if "token=" in msg or "authorization:" in msg:
                record.msg = "[redacted log line containing a token]"
                record.args = ()
            return True

    root.addFilter(_RedactFilter())
