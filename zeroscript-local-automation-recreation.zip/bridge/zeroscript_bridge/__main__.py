"""Entry point: ``python -m zeroscript_bridge``."""
from __future__ import annotations

import argparse
import sys

from .config import generate_default_config
from .server import run


def main() -> None:
    parser = argparse.ArgumentParser(prog="zeroscript_bridge", description="ZeroScript local bridge")
    parser.add_argument(
        "--init-config",
        action="store_true",
        help="Generate a default config.yaml and pairing token, then exit.",
    )
    args = parser.parse_args()

    if args.init_config:
        path = generate_default_config()
        print(f"Config ready at {path}")
        sys.exit(0)

    try:
        run()
    except KeyboardInterrupt:
        print("\nShutting down ZeroScript bridge (Ctrl+C received). Goodbye.")
        sys.exit(0)


if __name__ == "__main__":
    main()
