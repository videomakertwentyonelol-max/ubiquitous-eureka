"""Tracks the (single-user, local) session state between extension and bridge."""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field


@dataclass
class Session:
    session_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    client_version: str = ""
    platform: str = ""
    connected_at: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    tool_calls_handled: int = 0

    def touch(self) -> None:
        self.last_seen = time.time()

    def as_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "client_version": self.client_version,
            "platform": self.platform,
            "connected_at": self.connected_at,
            "last_seen": self.last_seen,
            "tool_calls_handled": self.tool_calls_handled,
        }


class SessionManager:
    def __init__(self) -> None:
        self._sessions: dict[str, Session] = {}

    def create(self, client_version: str, platform: str) -> Session:
        s = Session(client_version=client_version, platform=platform)
        self._sessions[s.session_id] = s
        return s

    def drop(self, session_id: str) -> None:
        self._sessions.pop(session_id, None)

    def all(self) -> list[Session]:
        return list(self._sessions.values())
