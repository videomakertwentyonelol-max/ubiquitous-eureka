"""Central allowlist of every tool the bridge is willing to execute.

Nothing is dispatched unless it is in this registry. This is populated
exclusively from the ``list_tools()`` of started integrations, so a tool
only appears if its integration is enabled in config.yaml (and, in the
case of dangerous tools like run_script/execute_code, explicitly turned on).
"""
from __future__ import annotations

from dataclasses import dataclass

from jsonschema import Draft202012Validator

from .integrations.base import Integration, ToolSpec


@dataclass
class RegisteredTool:
    spec: ToolSpec
    integration: Integration
    validator: Draft202012Validator


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, RegisteredTool] = {}

    def rebuild(self, integrations: list[Integration]) -> None:
        self._tools.clear()
        for integration in integrations:
            for spec in integration.list_tools():
                self._tools[spec.name] = RegisteredTool(
                    spec=spec,
                    integration=integration,
                    validator=Draft202012Validator(spec.argument_schema),
                )

    def get(self, tool_name: str) -> RegisteredTool | None:
        return self._tools.get(tool_name)

    def is_allowed(self, tool_name: str) -> bool:
        return tool_name in self._tools

    def list_public(self) -> list[dict]:
        return [
            {
                "name": t.spec.name,
                "description": t.spec.description,
                "argument_schema": t.spec.argument_schema,
                "consequential": t.spec.consequential,
            }
            for t in self._tools.values()
        ]
