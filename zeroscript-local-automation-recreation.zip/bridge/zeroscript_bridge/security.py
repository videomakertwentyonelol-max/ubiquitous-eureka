"""Security controls enforced independently of the browser extension.

The bridge never trusts the extension or the text an AI produced. Every
request is re-validated here: origin checks, token auth, size limits,
duplicate-request protection, tool allowlisting, and confirmation
requirements for consequential operations.
"""
from __future__ import annotations

import hmac
import logging
import re
import time
from dataclasses import dataclass, field
from typing import Any

from .config import SecurityConfig

logger = logging.getLogger("zeroscript.security")

_SECRET_KEY_RE = re.compile(r"(token|password|secret|api_key|authorization)", re.IGNORECASE)


def redact(obj: Any) -> Any:
    """Recursively redact likely-sensitive values before logging."""
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if isinstance(k, str) and _SECRET_KEY_RE.search(k):
                out[k] = "***REDACTED***"
            else:
                out[k] = redact(v)
        return out
    if isinstance(obj, list):
        return [redact(v) for v in obj]
    if isinstance(obj, str) and len(obj) > 300:
        return obj[:300] + "...<truncated>"
    return obj


class OriginNotAllowed(Exception):
    pass


class AuthenticationFailed(Exception):
    pass


class RequestTooLarge(Exception):
    pass


class DuplicateRequest(Exception):
    def __init__(self, request_id: str):
        super().__init__(f"Duplicate request_id already processed: {request_id}")
        self.request_id = request_id


def check_origin(origin: str | None, allowed_origins: list[str]) -> None:
    """Validate the WebSocket Origin header against the configured allowlist.

    Browser extensions send an Origin of ``chrome-extension://<id>``. If no
    origins are configured we fail closed (reject) rather than silently
    accepting any origin, to avoid an unconfigured bridge accepting
    connections from an unexpected extension.
    """
    if not allowed_origins:
        raise OriginNotAllowed(
            "No allowed_extension_origins configured. Add your extension's "
            "chrome-extension://<id> origin to config.yaml."
        )
    if origin not in allowed_origins:
        raise OriginNotAllowed(f"Origin '{origin}' is not in the configured allowlist")


def check_token(provided: str | None, expected: str) -> None:
    if not provided or not hmac.compare_digest(provided, expected):
        raise AuthenticationFailed("Invalid or missing pairing token")


@dataclass
class DuplicateGuard:
    """Tracks recently-seen request IDs to prevent re-execution."""

    ttl_seconds: int = 600
    _seen: dict[str, float] = field(default_factory=dict)

    def check_and_record(self, request_id: str) -> None:
        self._evict()
        now = time.monotonic()
        if request_id in self._seen:
            raise DuplicateRequest(request_id)
        self._seen[request_id] = now

    def _evict(self) -> None:
        now = time.monotonic()
        expired = [rid for rid, ts in self._seen.items() if now - ts > self.ttl_seconds]
        for rid in expired:
            del self._seen[rid]


def enforce_size_limit(raw_bytes: bytes, max_bytes: int, label: str = "message") -> None:
    if len(raw_bytes) > max_bytes:
        raise RequestTooLarge(f"{label} of {len(raw_bytes)} bytes exceeds limit of {max_bytes} bytes")


def requires_confirmation(tool_name: str, config: SecurityConfig) -> bool:
    return tool_name in config.require_confirmation_for
