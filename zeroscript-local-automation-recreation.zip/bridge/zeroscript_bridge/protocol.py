"""Structured, versioned protocol definitions shared with the browser extension.

The extension embeds tool-call requests inside the AI chat response as a
fenced code block tagged ``zeroscript-tool`` containing a JSON object that
matches :data:`TOOL_CALL_SCHEMA`. The extension parses and validates that
object *before* it ever reaches the bridge; the bridge re-validates
everything independently because the extension (and the text the AI wrote)
can never be trusted automatically.

Protocol version: ``zeroscript.tool_call/1`` and ``zeroscript.tool_result/1``.
"""
from __future__ import annotations

import dataclasses
import re
import time
import uuid
from typing import Any

from jsonschema import Draft202012Validator, ValidationError

PROTOCOL_TOOL_CALL = "zeroscript.tool_call/1"
PROTOCOL_TOOL_RESULT = "zeroscript.tool_result/1"
PROTOCOL_HELLO = "zeroscript.hello/1"

# Request IDs are produced by the extension as UUIDv4 strings.
_UUID_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)

# Tool names look like "<integration>.<action>", e.g. "roblox.get_instance_tree"
_TOOL_NAME_RE = re.compile(r"^[a-z][a-z0-9_]*\.[a-z][a-z0-9_]*$")

TOOL_CALL_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "ZeroScript Tool Call",
    "type": "object",
    "additionalProperties": False,
    "required": ["protocol", "request_id", "tool", "arguments"],
    "properties": {
        "protocol": {"const": PROTOCOL_TOOL_CALL},
        "request_id": {"type": "string", "pattern": _UUID_RE.pattern},
        "tool": {"type": "string", "pattern": _TOOL_NAME_RE.pattern, "maxLength": 128},
        "arguments": {"type": "object"},
        "created_at": {"type": "string", "maxLength": 64},
        "requires_confirmation": {"type": "boolean"},
        "source": {
            "type": "object",
            "additionalProperties": True,
            "properties": {
                "platform": {"type": "string", "maxLength": 64},
                "conversation_id": {"type": "string", "maxLength": 256},
            },
        },
    },
}

TOOL_RESULT_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "ZeroScript Tool Result",
    "type": "object",
    "additionalProperties": False,
    "required": ["protocol", "request_id", "status"],
    "properties": {
        "protocol": {"const": PROTOCOL_TOOL_RESULT},
        "request_id": {"type": "string", "pattern": _UUID_RE.pattern},
        "status": {"enum": ["ok", "error"]},
        "result": {},
        "error": {
            "type": "object",
            "properties": {
                "code": {"type": "string"},
                "message": {"type": "string"},
            },
        },
        "duration_ms": {"type": "number"},
    },
}

HELLO_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "ZeroScript Hello",
    "type": "object",
    "additionalProperties": False,
    "required": ["protocol", "type", "token", "client_version"],
    "properties": {
        "protocol": {"const": PROTOCOL_HELLO},
        "type": {"const": "hello"},
        "token": {"type": "string", "minLength": 8, "maxLength": 256},
        "client_version": {"type": "string", "maxLength": 32},
        "platform": {"type": "string", "maxLength": 64},
    },
}

_tool_call_validator = Draft202012Validator(TOOL_CALL_SCHEMA)
_tool_result_validator = Draft202012Validator(TOOL_RESULT_SCHEMA)
_hello_validator = Draft202012Validator(HELLO_SCHEMA)


class ProtocolError(Exception):
    """Raised when an inbound message does not satisfy the protocol."""

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


@dataclasses.dataclass(frozen=True)
class ToolCall:
    protocol: str
    request_id: str
    tool: str
    arguments: dict[str, Any]
    created_at: str | None = None
    requires_confirmation: bool = False
    source: dict[str, Any] | None = None

    @property
    def integration(self) -> str:
        return self.tool.split(".", 1)[0]

    @property
    def action(self) -> str:
        return self.tool.split(".", 1)[1]


def parse_tool_call(raw: dict[str, Any]) -> ToolCall:
    """Validate and parse a raw dict into a :class:`ToolCall`.

    Raises :class:`ProtocolError` on any structural problem. Never trusts
    the payload; this is the authoritative, independent validation step
    that happens inside the bridge regardless of what the extension already
    checked client-side.
    """
    if not isinstance(raw, dict):
        raise ProtocolError("invalid_payload", "Tool call payload must be a JSON object")

    errors = sorted(_tool_call_validator.iter_errors(raw), key=lambda e: e.path)
    if errors:
        first: ValidationError = errors[0]
        raise ProtocolError("schema_validation_failed", f"{first.message} at {list(first.path)}")

    return ToolCall(
        protocol=raw["protocol"],
        request_id=raw["request_id"],
        tool=raw["tool"],
        arguments=raw.get("arguments") or {},
        created_at=raw.get("created_at"),
        requires_confirmation=bool(raw.get("requires_confirmation", False)),
        source=raw.get("source"),
    )


def parse_hello(raw: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise ProtocolError("invalid_payload", "Hello payload must be a JSON object")
    errors = sorted(_hello_validator.iter_errors(raw), key=lambda e: e.path)
    if errors:
        first: ValidationError = errors[0]
        raise ProtocolError("schema_validation_failed", f"{first.message} at {list(first.path)}")
    return raw


def make_result(
    request_id: str,
    status: str,
    result: Any = None,
    error_code: str | None = None,
    error_message: str | None = None,
    duration_ms: float | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "protocol": PROTOCOL_TOOL_RESULT,
        "request_id": request_id,
        "status": status,
    }
    if status == "ok":
        payload["result"] = result
    else:
        payload["error"] = {"code": error_code or "unknown_error", "message": error_message or "Unknown error"}
    if duration_ms is not None:
        payload["duration_ms"] = round(duration_ms, 2)
    _tool_result_validator.validate(payload)
    return payload


def new_request_id() -> str:
    return str(uuid.uuid4())


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
