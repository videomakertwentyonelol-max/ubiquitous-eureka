"""Validates and routes a structured ToolCall to the correct integration.

This is the single choke point where every security control is enforced,
independent of whatever the browser extension already did:

1. The tool must be in the allowlist (``ToolRegistry``).
2. The serialized arguments must not exceed the configured size limit.
3. The arguments must satisfy the tool's JSON Schema.
4. Consequential tools require an explicit ``requires_confirmation: true``
   flag on the request (set only after the user approves in the extension
   UI); otherwise the dispatcher returns a ``confirmation_required`` error
   instead of running anything.
5. The request_id must not have been seen before (duplicate protection).
6. A timeout bounds how long any single tool call may run.
"""
from __future__ import annotations

import asyncio
import json
import logging
import time

from .config import BridgeConfig
from .integrations.base import IntegrationUnavailable
from .protocol import ProtocolError, ToolCall, make_result
from .security import DuplicateGuard, DuplicateRequest, enforce_size_limit, redact
from .tool_registry import ToolRegistry

logger = logging.getLogger("zeroscript.dispatcher")


class Dispatcher:
    def __init__(self, config: BridgeConfig, registry: ToolRegistry):
        self._config = config
        self._registry = registry
        self._dup_guard = DuplicateGuard(ttl_seconds=config.security.duplicate_request_ttl_seconds)

    async def dispatch(self, call: ToolCall) -> dict:
        start = time.monotonic()
        logger.info("tool_call request_id=%s tool=%s arguments=%s", call.request_id, call.tool, redact(call.arguments))

        try:
            self._dup_guard.check_and_record(call.request_id)
        except DuplicateRequest:
            return make_result(
                call.request_id,
                "error",
                error_code="duplicate_request",
                error_message="This request_id was already executed. Refusing to run it again.",
            )

        registered = self._registry.get(call.tool)
        if registered is None:
            return make_result(
                call.request_id,
                "error",
                error_code="tool_not_allowed",
                error_message=f"Tool '{call.tool}' is not registered/allowlisted on this bridge.",
            )

        try:
            raw_args_bytes = json.dumps(call.arguments).encode("utf-8")
        except (TypeError, ValueError):
            return make_result(
                call.request_id,
                "error",
                error_code="invalid_arguments",
                error_message="Arguments are not JSON-serializable.",
            )
        try:
            enforce_size_limit(raw_args_bytes, self._config.security.max_arguments_bytes, label="arguments")
        except Exception as exc:  # noqa: BLE001
            return make_result(call.request_id, "error", error_code="request_too_large", error_message=str(exc))

        errors = sorted(registered.validator.iter_errors(call.arguments), key=lambda e: e.path)
        if errors:
            first = errors[0]
            return make_result(
                call.request_id,
                "error",
                error_code="argument_validation_failed",
                error_message=f"{first.message} at {list(first.path)}",
            )

        if registered.spec.consequential and not call.requires_confirmation:
            return make_result(
                call.request_id,
                "error",
                error_code="confirmation_required",
                error_message=(
                    f"'{call.tool}' is a consequential operation and requires explicit user "
                    "confirmation. Re-send the same tool call with requires_confirmation: true "
                    "after the user approves it in the ZeroScript extension."
                ),
            )

        try:
            result = await asyncio.wait_for(
                registered.integration.call_tool(call.action, call.arguments),
                timeout=self._config.security.tool_call_timeout_seconds,
            )
            duration_ms = (time.monotonic() - start) * 1000
            logger.info("tool_result request_id=%s tool=%s status=ok duration_ms=%.1f", call.request_id, call.tool, duration_ms)
            return make_result(call.request_id, "ok", result=result, duration_ms=duration_ms)
        except asyncio.TimeoutError:
            duration_ms = (time.monotonic() - start) * 1000
            logger.warning("tool_result request_id=%s tool=%s status=timeout", call.request_id, call.tool)
            return make_result(
                call.request_id,
                "error",
                error_code="timeout",
                error_message=f"Tool call exceeded {self._config.security.tool_call_timeout_seconds}s timeout.",
                duration_ms=duration_ms,
            )
        except IntegrationUnavailable as exc:
            duration_ms = (time.monotonic() - start) * 1000
            logger.warning("tool_result request_id=%s tool=%s status=unavailable error=%s", call.request_id, call.tool, exc)
            return make_result(
                call.request_id, "error", error_code="integration_unavailable", error_message=str(exc), duration_ms=duration_ms
            )
        except ValueError as exc:
            duration_ms = (time.monotonic() - start) * 1000
            return make_result(call.request_id, "error", error_code="invalid_arguments", error_message=str(exc), duration_ms=duration_ms)
        except Exception as exc:  # noqa: BLE001
            duration_ms = (time.monotonic() - start) * 1000
            logger.exception("Unhandled error dispatching %s", call.tool)
            return make_result(
                call.request_id,
                "error",
                error_code="internal_error",
                error_message=f"Unhandled bridge error: {exc}",
                duration_ms=duration_ms,
            )
