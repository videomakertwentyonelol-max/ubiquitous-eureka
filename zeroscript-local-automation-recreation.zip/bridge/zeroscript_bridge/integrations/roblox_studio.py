"""Roblox Studio integration.

Connection mechanism (genuine, documented, and verifiable):

Roblox Studio plugins cannot open inbound sockets or run a server -- the
Studio Luau sandbox only allows *outbound* HTTP requests via
``HttpService``, and only when "Allow HTTP Requests" is enabled in
Game Settings > Security. This is the same constraint that the published
community Roblox Studio MCP bridges (local HTTP bridge + polling plugin)
work within, and it is why we do not invent a different "direct" connection.

So this integration runs an HTTP long-poll endpoint inside the bridge
itself (``/integrations/roblox/*``, bound to 127.0.0.1 only). The
companion Studio plugin (see ``roblox_plugin/ZeroScriptBridgePlugin.lua``)
repeatedly calls ``GET /poll``; when a tool call is queued, the plugin
receives it, executes it against the DataModel using the plugin's own
Luau APIs (wrapped in ``ChangeHistoryService`` waypoints so edits are
undoable), and reports the result back with ``POST /result``.

This module never claims a connection is live unless the plugin has sent a
heartbeat recently, and it never invents a result -- if the plugin does not
answer within the configured timeout, the tool call fails with a clear
"Roblox Studio is not connected" error.
"""
from __future__ import annotations

import asyncio
import logging
import time
import uuid
from typing import Any

from aiohttp import web

from ..config import RobloxConfig
from .base import Integration, IntegrationUnavailable, ToolSpec

logger = logging.getLogger("zeroscript.integrations.roblox")

HEARTBEAT_STALE_SECONDS = 15


class RobloxStudioIntegration(Integration):
    name = "roblox"

    def __init__(self, config: RobloxConfig, bridge_token: str):
        self._config = config
        self._token = bridge_token
        self._pending: dict[str, asyncio.Future] = {}
        self._queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue()
        self._last_heartbeat: float | None = None
        self._studio_info: dict[str, Any] = {}
        self._lock = asyncio.Lock()

    # ---- Integration lifecycle -------------------------------------------------
    async def start(self) -> None:
        logger.info("Roblox Studio integration ready (waiting for plugin to poll)")

    async def stop(self) -> None:
        for fut in self._pending.values():
            if not fut.done():
                fut.set_exception(IntegrationUnavailable("Bridge is shutting down"))
        self._pending.clear()

    def is_connected(self) -> bool:
        if self._last_heartbeat is None:
            return False
        return (time.monotonic() - self._last_heartbeat) < HEARTBEAT_STALE_SECONDS

    async def status(self) -> dict[str, Any]:
        return {
            "enabled": self._config.enabled,
            "connected": self.is_connected(),
            "last_heartbeat_age_seconds": (
                round(time.monotonic() - self._last_heartbeat, 1)
                if self._last_heartbeat is not None
                else None
            ),
            "studio_info": self._studio_info,
            "allow_run_script": self._config.allow_run_script,
            "pending_commands": self._queue.qsize(),
        }

    def list_tools(self) -> list[ToolSpec]:
        tools = [
            ToolSpec(
                name="roblox.get_instance_tree",
                description="Read the DataModel instance tree starting at a path (inspection only).",
                argument_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "root_path": {"type": "string", "maxLength": 512},
                        "max_depth": {"type": "integer", "minimum": 1, "maximum": 10},
                    },
                },
            ),
            ToolSpec(
                name="roblox.get_properties",
                description="Read properties of a single instance by path (inspection only).",
                argument_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["path"],
                    "properties": {
                        "path": {"type": "string", "maxLength": 512},
                        "property_names": {
                            "type": "array",
                            "items": {"type": "string", "maxLength": 128},
                            "maxItems": 50,
                        },
                    },
                },
            ),
            ToolSpec(
                name="roblox.set_properties",
                description="Set one or more properties on an existing instance. Wrapped in an undo waypoint.",
                consequential=True,
                argument_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["path", "properties"],
                    "properties": {
                        "path": {"type": "string", "maxLength": 512},
                        "properties": {"type": "object", "maxProperties": 50},
                    },
                },
            ),
            ToolSpec(
                name="roblox.create_instance",
                description="Create a new Instance under a parent path. Wrapped in an undo waypoint.",
                consequential=True,
                argument_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["parent_path", "class_name"],
                    "properties": {
                        "parent_path": {"type": "string", "maxLength": 512},
                        "class_name": {"type": "string", "maxLength": 128},
                        "name": {"type": "string", "maxLength": 128},
                        "properties": {"type": "object", "maxProperties": 50},
                    },
                },
            ),
            ToolSpec(
                name="roblox.delete_instance",
                description="Delete an instance by path. Wrapped in an undo waypoint.",
                consequential=True,
                argument_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["path"],
                    "properties": {"path": {"type": "string", "maxLength": 512}},
                },
            ),
        ]
        if self._config.allow_run_script:
            tools.append(
                ToolSpec(
                    name="roblox.run_script",
                    description=(
                        "DANGEROUS: execute arbitrary Luau in Studio's command bar context. "
                        "Disabled by default; must be explicitly enabled in config.yaml "
                        "(roblox.allow_run_script: true) and always requires confirmation."
                    ),
                    consequential=True,
                    argument_schema={
                        "type": "object",
                        "additionalProperties": False,
                        "required": ["code"],
                        "properties": {"code": {"type": "string", "maxLength": 20000}},
                    },
                )
            )
        return tools

    # ---- HTTP routes used by the Studio plugin ---------------------------------
    def register_http_routes(self, app: web.Application) -> None:
        app.router.add_get("/integrations/roblox/poll", self._handle_poll)
        app.router.add_post("/integrations/roblox/result", self._handle_result)
        app.router.add_post("/integrations/roblox/heartbeat", self._handle_heartbeat)
        app.router.add_get("/integrations/roblox/status", self._handle_status_http)

    def _check_plugin_token(self, request: web.Request) -> None:
        token = request.query.get("token") or request.headers.get("X-ZeroScript-Token")
        if token != self._token:
            raise web.HTTPUnauthorized(text="invalid plugin token")

    async def _handle_heartbeat(self, request: web.Request) -> web.Response:
        self._check_plugin_token(request)
        try:
            body = await request.json()
        except Exception:
            body = {}
        self._last_heartbeat = time.monotonic()
        self._studio_info = {
            "place_name": body.get("place_name"),
            "place_id": body.get("place_id"),
            "studio_version": body.get("studio_version"),
            "reported_at": time.time(),
        }
        return web.json_response({"ok": True})

    async def _handle_status_http(self, request: web.Request) -> web.Response:
        self._check_plugin_token(request)
        return web.json_response(await self.status())

    async def _handle_poll(self, request: web.Request) -> web.Response:
        self._check_plugin_token(request)
        self._last_heartbeat = time.monotonic()
        try:
            command = await asyncio.wait_for(
                self._queue.get(), timeout=self._config.poll_timeout_seconds
            )
            return web.json_response({"command": command})
        except asyncio.TimeoutError:
            return web.json_response({"command": None})

    async def _handle_result(self, request: web.Request) -> web.Response:
        self._check_plugin_token(request)
        body = await request.json()
        command_id = body.get("command_id")
        fut = self._pending.pop(command_id, None)
        if fut is None or fut.done():
            return web.json_response({"ok": False, "reason": "unknown or already-resolved command_id"}, status=404)
        if body.get("status") == "ok":
            fut.set_result(body.get("result"))
        else:
            fut.set_exception(
                IntegrationUnavailable(body.get("message") or "Studio plugin reported an error")
            )
        return web.json_response({"ok": True})

    # ---- Tool dispatch ----------------------------------------------------------
    async def call_tool(self, action: str, arguments: dict[str, Any]) -> Any:
        if not self._config.enabled:
            raise IntegrationUnavailable("Roblox Studio integration is disabled in config.yaml")
        if action == "run_script" and not self._config.allow_run_script:
            raise IntegrationUnavailable(
                "roblox.run_script is disabled. Set roblox.allow_run_script: true in config.yaml to enable it."
            )
        if not self.is_connected():
            raise IntegrationUnavailable(
                "Roblox Studio plugin is not connected. Open Roblox Studio, make sure "
                "'Allow HTTP Requests' is enabled (Home > Game Settings > Security), and "
                "confirm the ZeroScriptBridge plugin toolbar button shows 'Connected'."
            )

        command_id = str(uuid.uuid4())
        command = {"command_id": command_id, "action": action, "params": arguments}
        fut: asyncio.Future = asyncio.get_event_loop().create_future()
        self._pending[command_id] = fut
        await self._queue.put(command)
        try:
            result = await asyncio.wait_for(fut, timeout=self._config.command_timeout_seconds)
            return result
        except asyncio.TimeoutError as exc:
            self._pending.pop(command_id, None)
            raise IntegrationUnavailable(
                f"Timed out waiting {self._config.command_timeout_seconds}s for Roblox Studio "
                "to execute the command. Is Studio open and the plugin running?"
            ) from exc
