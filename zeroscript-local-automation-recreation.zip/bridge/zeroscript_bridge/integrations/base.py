"""Shared contract for MCP / local application integrations."""
from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass(frozen=True)
class ToolSpec:
    """Describes one allowlisted tool exposed by an integration."""

    name: str  # fully qualified, e.g. "roblox.get_instance_tree"
    description: str
    argument_schema: dict[str, Any]  # JSON Schema for `arguments`
    consequential: bool = False  # True => requires explicit confirmation
    handler: Callable[..., Any] | None = field(default=None, repr=False)


class IntegrationUnavailable(Exception):
    """Raised when an integration cannot currently service a request."""


class Integration(abc.ABC):
    """Base class for a local application integration (Roblox, Blender...)."""

    name: str

    @abc.abstractmethod
    async def start(self) -> None:
        """Start any background resources (servers, connections)."""

    @abc.abstractmethod
    async def stop(self) -> None:
        """Clean up resources."""

    @abc.abstractmethod
    def list_tools(self) -> list[ToolSpec]:
        """Return the tools this integration currently exposes.

        Must reflect genuine availability -- do not advertise tools that
        the connected application does not actually support right now.
        """

    @abc.abstractmethod
    async def status(self) -> dict[str, Any]:
        """Return a diagnostics dict describing current connection health."""

    @abc.abstractmethod
    async def call_tool(self, action: str, arguments: dict[str, Any]) -> Any:
        """Execute a tool. Raise IntegrationUnavailable / ValueError on failure."""
