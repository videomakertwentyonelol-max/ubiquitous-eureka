"""Sketchfab integration (optional).

Uses Sketchfab's official Data API v3 (https://docs.sketchfab.com/data-api/v3/).
Searching public models requires no authentication. Requesting a download
requires an Authorization header; this project uses a personal API token
("Authorization: Token <token>") configured locally by the user in
config.yaml or the ZEROSCRIPT_SKETCHFAB_TOKEN environment variable. The
token is never hardcoded and never logged.

This integration is independent of the core AI-to-MCP architecture and can
be disabled entirely (``sketchfab.enabled: false``, the default).
"""
from __future__ import annotations

import logging
import pathlib
import re
from typing import Any

import aiohttp

from ..config import SketchfabConfig
from .base import Integration, IntegrationUnavailable, ToolSpec

logger = logging.getLogger("zeroscript.integrations.sketchfab")

API_BASE = "https://api.sketchfab.com/v3"
_SAFE_NAME_RE = re.compile(r"[^A-Za-z0-9_.-]+")


class SketchfabIntegration(Integration):
    name = "sketchfab"

    def __init__(self, config: SketchfabConfig):
        self._config = config
        self._session: aiohttp.ClientSession | None = None

    async def start(self) -> None:
        self._session = aiohttp.ClientSession()

    async def stop(self) -> None:
        if self._session is not None:
            await self._session.close()
            self._session = None

    async def status(self) -> dict[str, Any]:
        return {
            "enabled": self._config.enabled,
            "has_api_token": bool(self._config.api_token),
            "download_dir": self._config.download_dir,
        }

    def list_tools(self) -> list[ToolSpec]:
        return [
            ToolSpec(
                name="sketchfab.search_models",
                description="Search publicly listed Sketchfab models.",
                argument_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["query"],
                    "properties": {
                        "query": {"type": "string", "maxLength": 256},
                        "downloadable": {"type": "boolean"},
                        "count": {"type": "integer", "minimum": 1, "maximum": 24},
                    },
                },
            ),
            ToolSpec(
                name="sketchfab.download_model",
                description=(
                    "Request an authorized download link for a model you have rights to "
                    "download, and save the archive locally. Requires a personal API token."
                ),
                consequential=True,
                argument_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["uid"],
                    "properties": {"uid": {"type": "string", "maxLength": 64}},
                },
            ),
        ]

    async def call_tool(self, action: str, arguments: dict[str, Any]) -> Any:
        if not self._config.enabled:
            raise IntegrationUnavailable("Sketchfab integration is disabled in config.yaml")
        if self._session is None:
            raise IntegrationUnavailable("Sketchfab integration is not started")

        if action == "search_models":
            return await self._search_models(arguments)
        if action == "download_model":
            return await self._download_model(arguments)
        raise IntegrationUnavailable(f"Unknown Sketchfab action: {action}")

    async def _search_models(self, arguments: dict[str, Any]) -> Any:
        params = {"type": "models", "q": arguments["query"]}
        if arguments.get("downloadable"):
            params["downloadable"] = "true"
        count = arguments.get("count", 10)
        async with self._session.get(f"{API_BASE}/search", params=params) as resp:
            if resp.status != 200:
                text = await resp.text()
                raise IntegrationUnavailable(f"Sketchfab search failed ({resp.status}): {text[:300]}")
            data = await resp.json()

        results = []
        for item in data.get("results", [])[:count]:
            results.append(
                {
                    "uid": item.get("uid"),
                    "name": item.get("name"),
                    "viewer_url": item.get("viewerUrl"),
                    "license": (item.get("license") or {}).get("label"),
                    "face_count": item.get("faceCount"),
                    "is_downloadable": item.get("isDownloadable"),
                    "user": (item.get("user") or {}).get("username"),
                }
            )
        return {"count": len(results), "results": results}

    async def _download_model(self, arguments: dict[str, Any]) -> Any:
        if not self._config.api_token:
            raise IntegrationUnavailable(
                "No Sketchfab API token configured. Add sketchfab.api_token to config.yaml "
                "(see https://sketchfab.com/settings/password) or set "
                "ZEROSCRIPT_SKETCHFAB_TOKEN."
            )
        uid = arguments["uid"]
        headers = {"Authorization": f"Token {self._config.api_token}"}
        async with self._session.get(f"{API_BASE}/models/{uid}/download", headers=headers) as resp:
            if resp.status != 200:
                text = await resp.text()
                raise IntegrationUnavailable(f"Sketchfab download request failed ({resp.status}): {text[:300]}")
            data = await resp.json()

        gltf = data.get("gltf") or {}
        download_url = gltf.get("url")
        if not download_url:
            raise IntegrationUnavailable("Sketchfab did not return a downloadable archive URL for this model")

        out_dir = pathlib.Path(self._config.download_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        safe_uid = _SAFE_NAME_RE.sub("_", uid)
        out_path = out_dir / f"{safe_uid}.zip"

        async with self._session.get(download_url) as file_resp:
            if file_resp.status != 200:
                raise IntegrationUnavailable(f"Failed to fetch archive ({file_resp.status})")
            with out_path.open("wb") as fh:
                async for chunk in file_resp.content.iter_chunked(65536):
                    fh.write(chunk)

        return {"uid": uid, "saved_to": str(out_path.resolve()), "expires_note": "download URL was single-use/time-limited"}
