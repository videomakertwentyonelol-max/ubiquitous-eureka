"""Blender integration.

Connection mechanism (genuine, documented): the bridge does **not** attempt
to reach into Blender's embedded Python interpreter from an unrelated
process -- that is not a supported mechanism. Instead, this integration
talks to a small companion Blender add-on
(``blender_addon/zeroscript_blender_addon.py``, included in this project)
that you install and enable inside Blender itself. The add-on opens a
plain TCP socket server bound to 127.0.0.1 (default port 9877) and speaks a
newline-delimited JSON request/response protocol defined in
``blender_addon/PROTOCOL.md``. This mirrors the same two-process pattern
used by the published BlenderMCP add-on (TCP socket server inside Blender +
an external client), but is an independent implementation written for this
project.

Every call opens a fresh connection, sends one JSON command, reads one JSON
response, and closes the connection. If Blender or the add-on is not
running, the connection attempt fails fast and a clear error is reported --
no operation is ever reported as successful without a genuine response
from Blender.
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from ..config import BlenderConfig
from .base import Integration, IntegrationUnavailable, ToolSpec

logger = logging.getLogger("zeroscript.integrations.blender")


class BlenderIntegration(Integration):
    name = "blender"

    def __init__(self, config: BlenderConfig):
        self._config = config

    async def start(self) -> None:
        logger.info(
            "Blender integration ready (will connect to %s:%s on demand)",
            self._config.host,
            self._config.port,
        )

    async def stop(self) -> None:
        return None

    async def status(self) -> dict[str, Any]:
        connected = False
        error = None
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(self._config.host, self._config.port),
                timeout=self._config.connect_timeout_seconds,
            )
            connected = True
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass
        except Exception as exc:  # noqa: BLE001
            error = str(exc)
        return {
            "enabled": self._config.enabled,
            "connected": connected,
            "host": self._config.host,
            "port": self._config.port,
            "error": error,
            "allow_execute_code": self._config.allow_execute_code,
        }

    def list_tools(self) -> list[ToolSpec]:
        tools = [
            ToolSpec(
                name="blender.get_scene_info",
                description="Inspect the current Blender scene: object list, active scene, frame range.",
                argument_schema={"type": "object", "additionalProperties": False, "properties": {}},
            ),
            ToolSpec(
                name="blender.get_object_info",
                description="Inspect a single object's transform, type, and mesh statistics.",
                argument_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["name"],
                    "properties": {"name": {"type": "string", "maxLength": 256}},
                },
            ),
            ToolSpec(
                name="blender.create_object",
                description="Create a primitive object (CUBE, SPHERE, CYLINDER, PLANE, CONE, TORUS, EMPTY).",
                consequential=True,
                argument_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["type"],
                    "properties": {
                        "type": {
                            "enum": ["CUBE", "SPHERE", "CYLINDER", "PLANE", "CONE", "TORUS", "EMPTY"]
                        },
                        "name": {"type": "string", "maxLength": 256},
                        "location": {"type": "array", "items": {"type": "number"}, "minItems": 3, "maxItems": 3},
                        "rotation": {"type": "array", "items": {"type": "number"}, "minItems": 3, "maxItems": 3},
                        "scale": {"type": "array", "items": {"type": "number"}, "minItems": 3, "maxItems": 3},
                    },
                },
            ),
            ToolSpec(
                name="blender.set_transform",
                description="Set location/rotation/scale of an existing object.",
                consequential=True,
                argument_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["name"],
                    "properties": {
                        "name": {"type": "string", "maxLength": 256},
                        "location": {"type": "array", "items": {"type": "number"}, "minItems": 3, "maxItems": 3},
                        "rotation": {"type": "array", "items": {"type": "number"}, "minItems": 3, "maxItems": 3},
                        "scale": {"type": "array", "items": {"type": "number"}, "minItems": 3, "maxItems": 3},
                    },
                },
            ),
            ToolSpec(
                name="blender.set_material_color",
                description="Create/assign a simple base-color material on an object.",
                consequential=True,
                argument_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["name", "color"],
                    "properties": {
                        "name": {"type": "string", "maxLength": 256},
                        "material_name": {"type": "string", "maxLength": 256},
                        "color": {
                            "type": "array",
                            "items": {"type": "number", "minimum": 0, "maximum": 1},
                            "minItems": 4,
                            "maxItems": 4,
                        },
                    },
                },
            ),
            ToolSpec(
                name="blender.delete_object",
                description="Delete an object by name.",
                consequential=True,
                argument_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["name"],
                    "properties": {"name": {"type": "string", "maxLength": 256}},
                },
            ),
        ]
        if self._config.allow_execute_code:
            tools.append(
                ToolSpec(
                    name="blender.execute_code",
                    description=(
                        "DANGEROUS: run arbitrary Python inside Blender via the add-on. "
                        "Disabled by default; enable with blender.allow_execute_code: true "
                        "in config.yaml. Always requires confirmation."
                    ),
                    consequential=True,
                    argument_schema={
                        "type": "object",
                        "additionalProperties": False,
                        "required": ["code"],
                        "properties": {"code": {"type": "string", "maxLength": 20000}},
                    },
                )
            )
        return tools

    async def call_tool(self, action: str, arguments: dict[str, Any]) -> Any:
        if not self._config.enabled:
            raise IntegrationUnavailable("Blender integration is disabled in config.yaml")
        if action == "execute_code" and not self._config.allow_execute_code:
            raise IntegrationUnavailable(
                "blender.execute_code is disabled. Set blender.allow_execute_code: true "
                "in config.yaml to enable it."
            )

        request = {"type": action, "params": arguments}
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(self._config.host, self._config.port),
                timeout=self._config.connect_timeout_seconds,
            )
        except Exception as exc:  # noqa: BLE001
            raise IntegrationUnavailable(
                f"Could not connect to the Blender add-on at {self._config.host}:"
                f"{self._config.port}. Open Blender, enable the ZeroScript add-on "
                "(Edit > Preferences > Add-ons) and click 'Start Server' in its panel. "
                f"Underlying error: {exc}"
            ) from exc

        try:
            payload = (json.dumps(request) + "\n").encode("utf-8")
            writer.write(payload)
            await writer.drain()
            line = await asyncio.wait_for(
                reader.readline(), timeout=self._config.command_timeout_seconds
            )
            if not line:
                raise IntegrationUnavailable("Blender add-on closed the connection without a response")
            response = json.loads(line.decode("utf-8"))
        except asyncio.TimeoutError as exc:
            raise IntegrationUnavailable(
                f"Timed out after {self._config.command_timeout_seconds}s waiting for Blender to respond"
            ) from exc
        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass

        if response.get("status") != "ok":
            raise IntegrationUnavailable(response.get("message") or "Blender add-on reported an error")
        return response.get("result")
