"""Local configuration loading for the ZeroScript bridge.

Configuration is loaded exclusively from local files. Nothing is fetched
from the network. Secrets (such as a Sketchfab API token) are read from a
local YAML file and/or environment variables -- never hardcoded, never
transmitted anywhere except to the documented third-party API they belong
to.
"""
from __future__ import annotations

import dataclasses
import os
import secrets
import string
from pathlib import Path

import yaml

DEFAULT_CONFIG_DIR = Path(__file__).resolve().parent.parent / "config"
DEFAULT_CONFIG_PATH = DEFAULT_CONFIG_DIR / "config.yaml"
EXAMPLE_CONFIG_PATH = DEFAULT_CONFIG_DIR / "config.example.yaml"
TOKEN_FILE_PATH = DEFAULT_CONFIG_DIR / "bridge_token.txt"


@dataclasses.dataclass
class RobloxConfig:
    enabled: bool = True
    poll_timeout_seconds: int = 25
    command_timeout_seconds: int = 30
    allow_run_script: bool = False


@dataclasses.dataclass
class BlenderConfig:
    enabled: bool = True
    host: str = "127.0.0.1"
    port: int = 9877  # distinct from third-party blender-mcp default (9876)
    connect_timeout_seconds: int = 5
    command_timeout_seconds: int = 30
    allow_execute_code: bool = False


@dataclasses.dataclass
class SketchfabConfig:
    enabled: bool = False
    api_token: str = ""
    download_dir: str = "./downloads/sketchfab"


@dataclasses.dataclass
class SecurityConfig:
    bind_host: str = "127.0.0.1"
    port: int = 8765
    allowed_extension_origins: list[str] = dataclasses.field(default_factory=list)
    max_message_bytes: int = 262144  # 256 KiB
    max_arguments_bytes: int = 65536
    tool_call_timeout_seconds: int = 45
    duplicate_request_ttl_seconds: int = 600
    require_confirmation_for: list[str] = dataclasses.field(
        default_factory=lambda: [
            "roblox.run_script",
            "roblox.delete_instance",
            "blender.execute_code",
            "blender.delete_object",
            "sketchfab.download_model",
        ]
    )


@dataclasses.dataclass
class BridgeConfig:
    token: str
    roblox: RobloxConfig = dataclasses.field(default_factory=RobloxConfig)
    blender: BlenderConfig = dataclasses.field(default_factory=BlenderConfig)
    sketchfab: SketchfabConfig = dataclasses.field(default_factory=SketchfabConfig)
    security: SecurityConfig = dataclasses.field(default_factory=SecurityConfig)
    log_level: str = "INFO"
    log_dir: str = "./logs"


def _generate_token(length: int = 40) -> str:
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


def ensure_token(token_file: Path = TOKEN_FILE_PATH) -> str:
    """Return the local pairing token, generating one on first run.

    The token authenticates the browser extension to the bridge. It is
    never sent anywhere except over the loopback WebSocket connection, and
    is stored only on the local filesystem.
    """
    token_file.parent.mkdir(parents=True, exist_ok=True)
    if token_file.exists():
        existing = token_file.read_text(encoding="utf-8").strip()
        if existing:
            return existing
    token = _generate_token()
    token_file.write_text(token, encoding="utf-8")
    return token


def generate_default_config(path: Path = DEFAULT_CONFIG_PATH) -> Path:
    """Write a safe default config.yaml if one does not already exist."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        return path
    token = ensure_token()
    default = {
        "security": {
            "bind_host": "127.0.0.1",
            "port": 8765,
            "allowed_extension_origins": [
                "chrome-extension://REPLACE_WITH_YOUR_EXTENSION_ID"
            ],
            "max_message_bytes": 262144,
            "max_arguments_bytes": 65536,
            "tool_call_timeout_seconds": 45,
            "duplicate_request_ttl_seconds": 600,
        },
        "roblox": {
            "enabled": True,
            "poll_timeout_seconds": 25,
            "command_timeout_seconds": 30,
            "allow_run_script": False,
        },
        "blender": {
            "enabled": True,
            "host": "127.0.0.1",
            "port": 9877,
            "connect_timeout_seconds": 5,
            "command_timeout_seconds": 30,
            "allow_execute_code": False,
        },
        "sketchfab": {
            "enabled": False,
            "api_token": "",
            "download_dir": "./downloads/sketchfab",
        },
        "log_level": "INFO",
        "log_dir": "./logs",
    }
    with path.open("w", encoding="utf-8") as fh:
        yaml.safe_dump(default, fh, sort_keys=False)
    return path


def load_config(path: Path | None = None) -> BridgeConfig:
    path = path or DEFAULT_CONFIG_PATH
    if not path.exists():
        generate_default_config(path)
    with path.open("r", encoding="utf-8") as fh:
        raw = yaml.safe_load(fh) or {}

    token = os.environ.get("ZEROSCRIPT_BRIDGE_TOKEN") or ensure_token()

    sec = raw.get("security", {})
    rbx = raw.get("roblox", {})
    bld = raw.get("blender", {})
    skf = raw.get("sketchfab", {})

    sketchfab_token = os.environ.get("ZEROSCRIPT_SKETCHFAB_TOKEN") or skf.get("api_token", "")

    return BridgeConfig(
        token=token,
        roblox=RobloxConfig(
            enabled=bool(rbx.get("enabled", True)),
            poll_timeout_seconds=int(rbx.get("poll_timeout_seconds", 25)),
            command_timeout_seconds=int(rbx.get("command_timeout_seconds", 30)),
            allow_run_script=bool(rbx.get("allow_run_script", False)),
        ),
        blender=BlenderConfig(
            enabled=bool(bld.get("enabled", True)),
            host=str(bld.get("host", "127.0.0.1")),
            port=int(bld.get("port", 9877)),
            connect_timeout_seconds=int(bld.get("connect_timeout_seconds", 5)),
            command_timeout_seconds=int(bld.get("command_timeout_seconds", 30)),
            allow_execute_code=bool(bld.get("allow_execute_code", False)),
        ),
        sketchfab=SketchfabConfig(
            enabled=bool(skf.get("enabled", False)),
            api_token=sketchfab_token,
            download_dir=str(skf.get("download_dir", "./downloads/sketchfab")),
        ),
        security=SecurityConfig(
            bind_host=str(sec.get("bind_host", "127.0.0.1")),
            port=int(sec.get("port", 8765)),
            allowed_extension_origins=list(sec.get("allowed_extension_origins", [])),
            max_message_bytes=int(sec.get("max_message_bytes", 262144)),
            max_arguments_bytes=int(sec.get("max_arguments_bytes", 65536)),
            tool_call_timeout_seconds=int(sec.get("tool_call_timeout_seconds", 45)),
            duplicate_request_ttl_seconds=int(sec.get("duplicate_request_ttl_seconds", 600)),
            require_confirmation_for=list(
                sec.get(
                    "require_confirmation_for",
                    SecurityConfig().require_confirmation_for,
                )
            ),
        ),
        log_level=str(raw.get("log_level", "INFO")),
        log_dir=str(raw.get("log_dir", "./logs")),
    )


if __name__ == "__main__":
    p = generate_default_config()
    print(f"Wrote default config to {p}")
    print(f"Pairing token stored at {TOKEN_FILE_PATH}")
