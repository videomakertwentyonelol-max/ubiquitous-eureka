#Requires -Version 5.1
<#
.SYNOPSIS
    Starts the ZeroScript local bridge.
.DESCRIPTION
    Launches the bridge inside its virtual environment. Binds to
    127.0.0.1 only. Press Ctrl+C to shut it down cleanly.
#>

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$BridgeRoot = Split-Path -Parent $ScriptDir
Set-Location $BridgeRoot

$VenvPython = Join-Path $BridgeRoot ".venv\Scripts\python.exe"
if (-not (Test-Path $VenvPython)) {
    Write-Error "Virtual environment not found. Run scripts\install_windows.ps1 first."
    exit 1
}

Write-Host "Starting ZeroScript bridge on 127.0.0.1 (loopback only). Press Ctrl+C to stop." -ForegroundColor Cyan
& $VenvPython -m zeroscript_bridge
