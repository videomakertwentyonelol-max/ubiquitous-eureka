@echo off
REM Double-click launcher for the ZeroScript bridge on Windows.
setlocal
set SCRIPT_DIR=%~dp0
set BRIDGE_ROOT=%SCRIPT_DIR%..
cd /d "%BRIDGE_ROOT%"

if not exist ".venv\Scripts\python.exe" (
    echo Virtual environment not found. Run scripts\install_windows.ps1 first.
    pause
    exit /b 1
)

echo Starting ZeroScript bridge on 127.0.0.1 ... press Ctrl+C to stop.
".venv\Scripts\python.exe" -m zeroscript_bridge
pause
