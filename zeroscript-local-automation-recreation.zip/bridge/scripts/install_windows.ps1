#Requires -Version 5.1
<#
.SYNOPSIS
    One-time setup for the ZeroScript local bridge on Windows.
.DESCRIPTION
    Creates a local Python virtual environment inside bridge\.venv,
    installs dependencies from requirements.txt, and generates a default
    config.yaml + pairing token. Does not require administrator privileges
    and does not install anything system-wide.
#>

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$BridgeRoot = Split-Path -Parent $ScriptDir
Set-Location $BridgeRoot

Write-Host "== ZeroScript Bridge :: Windows setup ==" -ForegroundColor Cyan

function Get-PythonCommand {
    foreach ($cmd in @("py -3", "python", "python3")) {
        $parts = $cmd.Split(" ")
        $exe = $parts[0]
        $found = Get-Command $exe -ErrorAction SilentlyContinue
        if ($found) { return $cmd }
    }
    return $null
}

$PythonCmd = Get-PythonCommand
if (-not $PythonCmd) {
    Write-Error "Python 3.10+ was not found on PATH. Install it from https://www.python.org/downloads/windows/ and re-run this script."
    exit 1
}
Write-Host "Using Python launcher: $PythonCmd"

if (-not (Test-Path "$BridgeRoot\.venv")) {
    Write-Host "Creating virtual environment (.venv)..."
    Invoke-Expression "$PythonCmd -m venv `"$BridgeRoot\.venv`""
} else {
    Write-Host "Virtual environment already exists, reusing it."
}

$VenvPython = Join-Path $BridgeRoot ".venv\Scripts\python.exe"

Write-Host "Upgrading pip..."
& $VenvPython -m pip install --upgrade pip | Out-Null

Write-Host "Installing dependencies from requirements.txt..."
& $VenvPython -m pip install -r "$BridgeRoot\requirements.txt"

Write-Host "Generating default config.yaml and pairing token (if not already present)..."
& $VenvPython -m zeroscript_bridge --init-config

Write-Host ""
Write-Host "Setup complete." -ForegroundColor Green
Write-Host "Next steps:"
Write-Host "  1. Edit bridge\config\config.yaml and add your extension's chrome-extension://<id> origin."
Write-Host "  2. Run bridge\scripts\start_bridge.ps1 (or start_bridge.bat) to launch the bridge."
Write-Host "  3. Load the extension (see docs\INSTALL_WINDOWS.md)."
