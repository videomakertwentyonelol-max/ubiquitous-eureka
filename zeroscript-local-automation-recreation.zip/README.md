# ZeroScript (independent functional recreation)

A local automation system that connects an AI chat session you already have
open in your own browser to local developer tools — Roblox Studio, Blender,
and optionally Sketchfab — through a browser extension, a local Python
bridge, and small, genuine integration modules.

This is **not** a website, SaaS product, or hosted service, and it does
**not** require or use a paid AI API. All AI inference happens in the chat
website you're already signed into; this project only validates and routes
already-structured tool-call requests to local tools.

```
extension/        Chrome/Edge Manifest V3 browser extension
bridge/            Local Python bridge (aiohttp, loopback-only)
roblox_plugin/     Roblox Studio plugin (.plugin.lua, no Rojo required)
blender_addon/     Blender add-on (TCP JSON socket server)
docs/              Full documentation (architecture, protocol, setup, security, testing)
src/, index.html   A static, local documentation/status viewer for this
                   generation environment only -- see note below. It is not
                   part of the product; the real deliverables are the four
                   folders above.
```

## Start here

Read [`docs/README.md`](docs/README.md), then
[`docs/INSTALL_WINDOWS.md`](docs/INSTALL_WINDOWS.md) for the full setup
walkthrough. Quick path:

```powershell
cd bridge
powershell -ExecutionPolicy Bypass -File scripts\install_windows.ps1
bridge\scripts\start_bridge.ps1
```

Then load `extension/` as an unpacked extension in Chrome/Edge (Developer
Mode > Load unpacked), pair it with the token printed in
`bridge/config/bridge_token.txt`, and follow the rest of
`docs/INSTALL_WINDOWS.md`.

## A note about `src/` and `index.html` in this repository

The tooling used to generate this project is a React/Vite web-app builder
and can only build and preview a single web page. Since ZeroScript itself
is explicitly **not** a website, `src/App.tsx` here is just a static,
read-only documentation index for browsing what was generated — it has no
runtime behavior, calls no APIs, and is not loaded by the extension or the
bridge. The actual product is the browser extension in `extension/`, the
Python bridge in `bridge/`, and the integration modules in
`roblox_plugin/`/`blender_addon/`.

## What's genuinely verified vs. not

See [`docs/README.md`](docs/README.md#what-is-genuinely-verified-vs-not)
and [`docs/TESTING.md`](docs/TESTING.md) for an explicit breakdown of what
has automated tests, what those tests mock, and what can only be verified
on your own Windows PC with Chrome/Edge, Roblox Studio, and/or Blender
installed.
